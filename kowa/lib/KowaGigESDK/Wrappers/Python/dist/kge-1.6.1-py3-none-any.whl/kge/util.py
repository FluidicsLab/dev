# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import itertools

from logging import getLogger
logger = getLogger(__name__)

class MergeAttributes():
    """
    mock merge args attributes.
    usage:
        m = MergeAttributes(os, sys)
        m.makedirs("d") # same 'os.makedirs("d")'
        print(m.argv)   # same 'print(sys.argv)'
    """
    def __init__(self, *args):
        self._children = args
    def __getattr__(self, name):
        if not name.startswith("__"):
            for child in self._children:
                if hasattr(child, name):
                    return getattr(child, name)
        # no has attribute
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
    def __dir__(self):
        childattributes = itertools.chain(*map(dir, self._children))
        extra = filter(lambda x:not x.startswith("__"), childattributes)
        original = object.__dir__(self)
        return sorted(set(original) | set(extra))

def class_attributes_adder(**class_attributes):
    """
    class decorator.
    usage:
        @class_attributes_adder(number=42)
        class A:
            ...
        print(A.number) # -> 42

        @class_attributes_adder(**{"number":42})
        class B:
            ...
        print(B.number) # -> 42
    """
    def core(target_class):
        for k,v in class_attributes.items():
            setattr(target_class, k, v)
        return target_class
    return core

def enable_ansi_escape_sequence():
    """
    force enable escape sequence (windows only)
    e.g. print("\x1b[31mRed String\x1b[0m")
    """
    if os.name != "nt":
        return

    import ctypes # pylint: disable = import-outside-toplevel
    if not hasattr(ctypes, "windll"):
        return
    if not hasattr(ctypes.windll, "kernel32"):
        return

    logger.info("")
    k32 = ctypes.windll.kernel32
    STD_OUTPUT_HANDLE = ctypes.c_uint32(-11) # pylint: disable = invalid-name
    ENABLE_VIRTUAL_TERMINAL_PROCESSING = ctypes.c_uint32(4) # pylint: disable = invalid-name

    mode = ctypes.c_uint32()
    hstdout = k32.GetStdHandle(STD_OUTPUT_HANDLE)

    k32.GetConsoleMode(hstdout, ctypes.byref(mode))
    newmode = ctypes.c_uint32(mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING.value)
    k32.SetConsoleMode(hstdout, newmode)
    # Note: Do not close hstdout
