# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import sys

import typing
from logging import getLogger

import ctypes
import ctypes as _c

from .. import geverror
from .. import cwrapper
from .. import cwrapper as _cw
from .. import structures
from .. import functions
from . import _loadcore

logger = getLogger(__name__)

# Note:
#     for cwrapper.py type annotation to works,
#     you must use python3.10 or later.
if sys.version_info >= (3, 10):
    _TypeVar = typing.TypeVar('_TypeVar')
    _ParamSpec = typing.ParamSpec('_ParamSpec')
else:
    _TypeVar = typing.Any
    _ParamSpec = ...


callwrapper = _cw.CWrapper(_loadcore.dll,
                           functions._camelCase2PascalCase(lambda s:"RemoteFocus"+s),
                           _cw.ReturnMode.ErrorCode(geverror.GEVError, _c.c_uint16))


_inConvertCameraToCameraNo = functions._OpenedCamera._inConvertSelfToCameraNo

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getFWVersion(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32)
def __RemoteFocusAddStepCount(camera: functions._OpenedCamera, step_count: int):
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32)
def __RemoteFocusSubStepCount(camera: functions._OpenedCamera, step_count: int):
    return ... # type:ignore

# switch call to API functions by step_count sign.
def addStepCount(camera: functions._OpenedCamera, step_count: int):
    if step_count >= 0:
        return __RemoteFocusAddStepCount(camera, step_count)
    else:
        return __RemoteFocusSubStepCount(camera, -step_count)

def subStepCount(camera: functions._OpenedCamera, step_count: int):
    if step_count >= 0:
        return __RemoteFocusSubStepCount(camera, step_count)
    else:
        return __RemoteFocusAddStepCount(camera, -step_count)

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_int16))
def getStepCount(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo)
def setOrigin(camera: functions._OpenedCamera):
    return ... # type:ignore

# TODO: change returnvalue from int to enum.
@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_int))
def getOriginState(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo)
def forceStop(camera: functions._OpenedCamera):
    return ... # type:ignore


@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32)
def setPPS(camera: functions._OpenedCamera, pps: int) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getPPS(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

# TODO: change motor_phase from int to enum.
@callwrapper(_inConvertCameraToCameraNo, _c.c_int)
def setMotorPhase(camera: functions._OpenedCamera, motor_phase: int):
    return ... # type:ignore

# TODO: change returnvalue from int to enum.
@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_int))
def getMotorPhase(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32)
def setCanMotorSleep(camera: functions._OpenedCamera, motor_state: int) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getCanMotorSleep(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

class Info(structures.AutoReprStructure):
    _fields_ = [
        ("flags"           , _c.c_uint8),
        ("is_busy"         , _c.c_uint8),
        ("step_count"      , _c.c_int16),
        ("origin_state"    , _c.c_uint8),
        ("slit_position"   , _c.c_uint8),
    ]

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(Info))
def getInfo(camera: functions._OpenedCamera) -> Info:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def isMotorBusy(camera: functions._OpenedCamera) -> bool:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getSlitLocation(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getFlags(camera: functions._OpenedCamera) -> int:
    return ... # type:ignore
