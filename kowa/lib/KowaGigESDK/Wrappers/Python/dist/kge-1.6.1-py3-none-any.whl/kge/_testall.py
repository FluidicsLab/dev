# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

"""
test all file in this directory, with prefix is "_test_".
"""

import sys
import os

import unittest
import traceback
import importlib

def removesuffix(s: str, remove: str) -> str:
    if sys.version_info >= (3, 9):
        return s.removesuffix(remove)

    if not remove:
        return s
    if s.endswith(remove):
        return s[:-len(remove)]
    else:
        return s

def load(fname):
    try:
        return importlib.import_module(removesuffix(fname, ".py"))
    except Exception:
        traceback.print_exc()
        return None


def _istarget(fname):
    return all([
        fname.startswith("_test_"),
        fname.endswith(".py"),
    ])

def execute(module) -> bool:
    if module is None:
        return False
    res = unittest.main(module, exit=False)
    return not (res.result.errors or res.result.failures)

def testall():
    dname=os.path.dirname(__file__)
    files=tuple(filter(_istarget, os.listdir(dname)))
    modules = map(load, files)
    succeed = tuple(map(execute, modules))
    return all(succeed)

if __name__ == "__main__":
    sys.exit(0 if testall() else 1)
