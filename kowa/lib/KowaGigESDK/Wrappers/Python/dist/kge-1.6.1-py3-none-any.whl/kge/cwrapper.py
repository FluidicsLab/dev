# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import sys

import ctypes
import _ctypes
import abc

import inspect
import functools
import typing

# Note:
#     for cwrapper.py type annotation to works,
#     you must use python3.10 or later.
if sys.version_info >= (3, 10):
    _TypeVar = typing.TypeVar('_TypeVar')
    _ParamSpec = typing.ParamSpec('_ParamSpec')
else:
    _TypeVar = typing.Any
    _ParamSpec = ...



_CtypesCData = ctypes.c_int.__mro__[-2]
_AnyLengthString = ctypes.c_uint8*0

def _isarray(t: typing.Union[type, typing.Any]):
    if isinstance(t, type):
        return issubclass(t, ctypes.Array)
    else:
        return isinstance(t, ctypes.Array)

def _to_cstring_buf(s: typing.Union[str, int]) -> _AnyLengthString:
    """
    str to char* buffer (0 terminated).
    int to char [N] buffer.
    """
    if isinstance(s, int):
        return (ctypes.c_uint8*(s+1))()
    pb=s.encode()
    cb=(ctypes.c_uint8*(len(pb)+1))(*pb)
    cb[-1]=0
    return cb


"""
target_type is like...
class T(ctypes.Structure):
    @staticmethod
    def convert_to_ctypes(value):
        return T(...)
    def convert_from_ctypes(self):
        return ...
"""
def _convert_to_ctype(target_type: typing.Type[_CtypesCData], value):
    # not convert, if some special case.
    # already target type.
    if isinstance(value, target_type):
        return value
    # already target array type
    if _isarray(target_type) and _isarray(value) and(
            target_type._type_ is value._type_
    ):
        return value
    if issubclass(_ctypes.CFuncPtr, target_type):
        return value

    if hasattr(target_type, "convert_to_ctypes"):
        return target_type.convert_to_ctypes(value)
    # c_char*N: str -> null-terminated string
    if target_type is ctypes.c_char*0:
        if not isinstance(value, str):
            raise TypeError("value must be str.")
        return _to_cstring_buf(value)
    # c_char*N: str -> null-terminated string
    if hasattr(target_type, "_type_") and target_type._type_ is ctypes.c_char:
        if not isinstance(value, str):
            raise TypeError("value must be str.")
        return target_type(*(value+"\0").encode())
    # array
    if _isarray(target_type):
        if target_type._length_ == 0:
            # Note: care generator object
            v = tuple(value)
            return (target_type._type_ * len(v))(*v)
        else:
            return target_type(*value)
    # other
    return target_type(value)

_ctype2pytype = {
    ctypes.c_int8: int,
    ctypes.c_int16: int,
    ctypes.c_int32: int,
    ctypes.c_int64: int,
    ctypes.c_uint8: int,
    ctypes.c_uint16: int,
    ctypes.c_uint32: int,
    ctypes.c_uint64: int,
    ctypes.c_bool: bool,
    ctypes.c_float: float,
    ctypes.c_double: float,
}

def _convert_from_ctype(value):
    from_type=type(value)
    no_converts = {
        ctypes.c_int8,  ctypes.c_uint8,
        ctypes.c_int16, ctypes.c_uint16,
        ctypes.c_int32, ctypes.c_uint32,
        ctypes.c_int64, ctypes.c_uint64,
        ctypes.c_bool,
        ctypes.c_float,
        ctypes.c_double,
        ctypes.c_void_p,
    }
    if hasattr(value, "convert_from_ctypes"):
        return value.convert_from_ctypes()
    # c_char*N: null-terminated string -> str
    if hasattr(from_type, "_type_") and from_type._type_ is ctypes.c_char:
        return value.raw.split(b"\x00", 1)[0].decode()
    # c_char -> 1 length str
    if from_type is ctypes.c_char:
        return chr(value.value[0])
    if from_type in no_converts:
        return value.value
    # array
    if _isarray(value):
        if value._type_ is ctypes.c_uint8:
            return bytes(value)
        if value._type_ in _ctype2pytype:
            return tuple(map(_ctype2pytype[value._type_], value))
    # other(e.g. struct). no convert
    return value

def BoolLike(t: _CtypesCData) -> type:
    """
    usage: In(BoolLike(c_int32))
    usage: In(BoolLike(c_int16))
    usage: Out(BoolLike(c_int))
    """
    class _BoolLike(ctypes.Structure):
        """
        extra converter for ctypes.
        """
        _fields_ = [
            ("value", t),
        ]
        @staticmethod
        def convert_to_ctypes(value: bool):
            return _BoolLike(int(bool(value)))
        def convert_from_ctypes(self):
            return bool(self.value)
    return _BoolLike


class CWrapperError(Exception):
    error_code: typing.Any

    # Cation:
    #     this values count is not surely decided.
    #     e.g.
    #         try:
    #             a,b,c = func3()
    #         except CWrapperError as ex:
    #             # surely 3 count.
    #             a,b,c = ex.missing_returned_value
    #     e.g.
    #         try:
    #             a,b,c,d = func4()
    #         except CWrapperError as ex:
    #             # surely 4 count.
    #             a,b,c,d = ex.missing_returned_value
    #     e.g.
    #         try:
    #             a,b,c = func3()
    #             a,b,c,d = func4()
    #         except CWrapperError as ex:
    #             # 3 or 4 count.
    #             print(ex.missing_returned_value)
    missing_returned_value: typing.Optional[
        typing.Union[
            typing.Tuple[typing.Any, ...],
            typing.Any,
        ]
    ]

    _assert_missing_table_message = "missing '_raise_table' at class definition"
    """
    any errors helper.
    usage: see also "_test_cwrapper_.py"
    e.g.
    class CError(CWrapperError):
        pass
    class ExistError(CError):
        pass
    class NotDirectoryError(CError):
        pass
    CError.add_raisetype({0:None}) # no error
    CError.add_raisetype({17:ExistError, 20:NotDirectoryError}) # special errors
    CError.raise_iferror(0) # not raise
    CError.raise_iferror(2) # raise CError (default)
    CError.raise_iferror(5) # raise CError (default)
    CError.raise_iferror(17)# raise ExistError
    """
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "_raise_table"):
            cls._raise_table={}
        else:
            cls._raise_table=cls._raise_table.copy()
    def __init__(self, error_code):
        self.error_code=error_code
    def __str__(self):
        mes = self.error_to_string()
        if isinstance(mes, str):
            return f"[{self.error_code}]: {self.error_to_string()}"
        else:
            return f"[{self.error_code}]"
    def __repr__(self):
        return f"{self.__class__.__name__}({self.error_code})"

    def error_to_string(self) -> typing.Optional[str]:
        """ return readable error message. """
        return NotImplemented
    @classmethod
    def add_raisetype(cls, types: typing.Dict["errortype", "ExceptionType(cls)"]):
        assert hasattr(cls, "_raise_table"), cls._assert_missing_table_message
        assert all(issubclass(x, cls) for x in types.values() if x is not None)
        cls._raise_table.update(types)
    @classmethod
    def raise_iferror(cls, error_code):
        assert hasattr(cls, "_raise_table"), cls._assert_missing_table_message
        etype=cls._raise_table.get(error_code, cls)
        if etype is not None:
            raise etype(error_code)

class ArgumentMode(abc.ABC):
    subclasses : typing.ClassVar[typing.List["ArgumentMode"]]
    subclasses = []
    def __init_subclass__(cls, **kwargs):
        """
        treat subclass as innerclass.
        e.g.
            class SubClass(ThisClass): ...
            # SubClass is ThisClass.SubClass
        """
        super().__init_subclass__(**kwargs)
        setattr(__class__, cls.__name__, cls)
        __class__.subclasses.append(cls)
    def __init__(self, ctype: typing.Type[_CtypesCData]):
        assert isinstance(ctype, type), f"ctype requires 'ctypes' type: ({ctype})"
        assert issubclass(ctype, _CtypesCData), (
            f"type '{ctype.__class__.__name__}' is not C compatible data type"
        )
        self.ctype=ctype
    @staticmethod
    def auto_in(argtype: typing.Union[typing.Type[_CtypesCData], typing.Type["ArgumentMode"]]):
        """ wrap In(argtype) if argtype is not ArgumentMode."""
        if isinstance(argtype, __class__):
            return argtype
        return __class__.In(argtype)
    @staticmethod
    def convert_cbuffer(signature: typing.Tuple["ArgumentMode", ...],
                        pyargs: typing.Tuple[typing.Any, ...]) -> typing.Tuple[
                            typing.Tuple[_CtypesCData, ...],
                            typing.Tuple[_CtypesCData, ...],
                        ]:
        def isout(mode:__class__):
            return isinstance(mode, __class__.Out)
        def isinexpression(mode):
            return isinstance(mode, __class__.InExpression)
        # forrow InExpression type
        for inex in filter(isinexpression, signature):
            inex.update_args(*pyargs)

        iterargs=iter(pyargs)
        cbuffers=tuple(mode.cbuffer(iterargs) for mode in signature)
        obuffers=tuple(buf._obj for buf, mode in zip(cbuffers, signature) if isout(mode))
        return (cbuffers, obuffers)
    @abc.abstractmethod
    def cbuffer(self, iterator) -> _CtypesCData:
        pass


class In(ArgumentMode):
    """
    a In value argument.
    e.g.
        // In(c_int)
        // python: f(42)
        void f(int arg){ printf("%d\n", arg);}
    e.g.
        // In(S)
        // python: f(st1)
        void f(struct st){ printf("%d\n", st.value);}
    e.g.
        // In(c_char*0)
        // python: f("test")
        void f(const char* s){ printf("%s\n", s);}
    """
    def cbuffer(self, iterator):
        return _convert_to_ctype(self.ctype, next(iterator))

class Out(ArgumentMode):
    """
    a Out value argument.
    python does not explicitly give argument to function.
    e.g.
        // Out(c_int)
        // python: res = f()
        void f(int* buf){ *buf = 9;}
    e.g.
        // Out(c_char*256) # buffersize=256
        // python: res=f()
        void f(char* s){ strcpy(s, "test");}
    e.g.
        // In(c_int), Out(c_int), In(c_int)
        // python: res = f(16,32)
        void f(int a, int* buf, int b){ *buf = a+b;}
    """
    allow_anylength=False
    # special treatment for superclass.
    def __init__(self, ctype:typing.Type[_CtypesCData]):
        if getattr(ctype, "_length_", None) == 0 and not self.allow_anylength:
            raise TypeError("OutBuffer must not 0 length Array.")
        super().__init__(ctype)
    def cbuffer(self, iterator):
        return ctypes.byref(self.ctype())

class InRef(ArgumentMode):
    """
    a In pointer or array argument.
    e.g.
        // InRef(c_int*0), In(c_int)
        // python: f([1,2,3,4])
        void f(const int arr[], int size) {
            for(int i=0; i<size; ++i) {
                printf("[%d]: %d\n", i, arr[i]);
            }
        }
    e.g.
        // InRef(S)
        // python: res = f(st1)
        void f(const struct S* st){ printf("%d\n", st->value);}
    """
    def cbuffer(self, iterator):
        return ctypes.byref(_convert_to_ctype(self.ctype, next(iterator)))

class Buffer(ArgumentMode):
    """
    a In/Out Buffer.
    python needs explicitly create and give ctypes buffer
    e.g.
        // Buffer(c_int*0), In(c_int)
        // python: arr=(c_int*16)(); f(arr, 16)
        void f(int arr[], int size){
            for(int i=0; i<size; ++i) {
                buf[i]++;
            }
        }
    e.g.
        // Buffer(S)
        // python: st1=S(); f(st1)
        void f(struct S* st){ st->value = 42;}
    """
    def cbuffer(self, iterator):
        return ctypes.byref(next(iterator))

class InExpression(ArgumentMode):
    """
    a In value argument.
    this augument is calculated by other argument.
    e.g.
        // In(c_int), In(c_int), InExpression(c_int, lambda v1,v2:v1*v2)
        // python: f(5,7)
        void f(int v1, int v2, int v3){
            printf("%d,%d,%d\n", v1, v2, v3); // "5,7,35"
        }
    """
    # special treatment for superclass.
    # TODO: func type-annotation
    def __init__(self, ctype:typing.Type[_CtypesCData], func:typing.Callable):
        super().__init__(ctype)
        self._func = func
        self._avaivable = False
        self._cvalue = None
    def update_args(self, *args):
        value=self._func(*args)
        self._cvalue=_convert_to_ctype(self.ctype, value)
        self._avaivable=True
    def cbuffer(self, iterator):
        assert self._avaivable, "this is not avaivable. missing call 'update_args',"
        self._avaivable=False
        return self._cvalue

class OutExpression(InExpression, Out):
    """
    a Out value argument.
    this augument is calculated by other argument.
    for decide buffer size.
    e.g.
        // OutExpression(c_int*0, lambda s:(c_uint32*s)()), In(c_int),
        // python: res=f(4) # (0,1,2,3)
        void f(int buf[], int size){
            for(int i=0; i<size; ++i) {
                buf[i]=i;
            }
        }
    """
    allow_anylength=True
    def cbuffer(self, iterator):
        return ctypes.byref(InExpression.cbuffer(self, iterator))

class InConvert(ArgumentMode):
    """
    a In value argument.
    this augument is calculated by *this* argument.
    e.g.
        // InConvert(c_int, labmda a:create_S(a))
        // or... InConvert(c_int, create_S)
        // python: f(5)
        void f(struct S st){ printf("%d\n", st.value);}
    """
    def __init__(self, ctype:typing.Type[_CtypesCData], func:typing.Callable):
        super().__init__(ctype)
        self._func=func
    def cbuffer(self, iterator):
        value=self._func(next(iterator))
        return _convert_to_ctype(self.ctype, value)

class InRefConvert(ArgumentMode):
    """
    a In pointer or array argument.
    this augument is calculated by *this* argument.
    e.g.
        // InConvert(c_int, labmda a:create_S(a))
        // or... InConvert(c_int, create_S)
        // python: f(5)
        void f(const struct S* st){ printf("%d\n", st->value);}
    """
    def __init__(self, ctype:typing.Type[_CtypesCData], func:typing.Callable):
        super().__init__(ctype)
        self._func=func
    def cbuffer(self, iterator):
        value=self._func(next(iterator))
        return ctypes.byref(_convert_to_ctype(self.ctype, value))

class InConstant(ArgumentMode):
    """
    a In constant argument.
    e.g.
        // InConstant(c_int, 57)
        // python: f()
        void f(int arg){ printf("%d\n", arg);}
    """
    def __init__(self, ctype:typing.Type[_CtypesCData], value):
        super().__init__(ctype)
        self._cvalue=_convert_to_ctype(ctype, value)
    def cbuffer(self, iterator):
        return self._cvalue


class ReturnMode(abc.ABC):
    subclasses : typing.ClassVar[typing.List["ReturnMode"]]
    subclasses=[]
    def __init_subclass__(cls, **kwargs):
        """
        treat subclass as innerclass.
        e.g.
            class SubClass(ThisClass): ...
            # SubClass is ThisClass.SubClass
        """
        super().__init_subclass__(**kwargs)
        setattr(__class__, cls.__name__, cls)
        __class__.subclasses.append(cls)

    @abc.abstractmethod
    def confirm_returned_value(self, c_returnedvalue:int) -> typing.Optional[_CtypesCData]:
        pass
    @staticmethod
    def auto_instance(mode: typing.Union[typing.Type["ReturnMode"], "ReturnMode"]):
        if isinstance(mode, type) and issubclass(mode, __class__):
            return mode()
        if isinstance(mode, __class__):
            return mode
        raise TypeError(f"mode({mode}) requires type '{__class__.__name__}' or that instance")


class Take(ReturnMode):
    def __init__(self, rettype:_CtypesCData):
        self._type=rettype
    def confirm_returned_value(self, c_returnedvalue:int) -> _CtypesCData:
        return self._type(c_returnedvalue)

class TakeInt(Take):
    def __init__(self):
        super().__init__(ctypes.c_int)

class Ignore(ReturnMode):
    def confirm_returned_value(self, c_returnedvalue:int) -> None:
        pass

class ErrorCode(ReturnMode):
    def __init__(self, exception_type:typing.Type[CWrapperError], native_returntype:_CtypesCData):
        assert isinstance(exception_type, type) and issubclass(exception_type, CWrapperError), (
            "'exception_type' requires 'CWrapperError or subclass type.'"
        )
        assert isinstance(native_returntype, type), (
            f"native_returntype requires 'ctypes' type. ({native_returntype})"
        )
        self._exception_type=exception_type
        self.native_returntype=native_returntype
    def confirm_returned_value(self, c_returnedvalue:int):
        value=self.native_returntype(c_returnedvalue).value
        self._exception_type.raise_iferror(value)

class IntErrorCode(ErrorCode):
    def __init__(self, exception_type: typing.Type[CWrapperError]):
        super().__init__(exception_type, ctypes.c_int)


class Boolean(ReturnMode):
    """ If you donnot error handle, use "Ignore". """
    def __init__(self, exception_type:typing.Type[CWrapperError],
                 errorcode_getter: typing.Optional[typing.Callable]=None):
        # errorhandler must be... errorcode_getter() -> errorcode
        # e.g.
        #     @wrapper(returnmode=TakeInt)
        #     def SDKGetLastErrorCode(): ...
        #     def errorcode_getter():
        #         return SDKGetLastErrorCode()
        self._exception_type=exception_type
        self._errorcode_getter = errorcode_getter
    def confirm_returned_value(self, c_returnedvalue:int):
        """ raise error if returnvalue is false(0). """
        if not c_returnedvalue:
            if self._errorcode_getter is not None:
                ecode=self._errorcode_getter()
                self._exception_type.raise_iferror(ecode)
            else:
                raise self._exception_type(None)

class _CWrapperCore:
    def __init__(self, c_funcptr:"ctypes FuncPtr",
                 pyfunc, # for repr
                 *csignature: typing.Tuple[ArgumentMode],
                 returnmode: ReturnMode,
                 ):
        self.funcptr=c_funcptr
        self.pyfunc=pyfunc
        self.csignature=csignature
        self.returnmode=returnmode

        self._pyfunc_signature=inspect.signature(pyfunc)
        self._c_out_signature=tuple(x.ctype for x in csignature if isinstance(x, ArgumentMode.Out))

    def __repr__(self):
        vs=inspect.signature(self.pyfunc).parameters.values()
        return (
            f"<{__class__.__name__} {self.pyfunc.__name__}({', '.join(map(str, vs))}) - "
            f"{self.returnmode.__class__.__name__}>"
        )
    def __call__(self, *args, **kwargs):
        trueargs=self._get_trueargs(*args, **kwargs)
        c_args, outbufs = ArgumentMode.convert_cbuffer(self.csignature, trueargs)
        assert len(self.csignature) == len(c_args), (
            "cdll argument and signature are not match."
            f"Canceled, will pass arguments to C lang: {c_args},"
            f"signature: {self.csignature},"
        )
        returncode = self.funcptr(*c_args)
        try:
            res = self.returnmode.confirm_returned_value(returncode)
        except CWrapperError as ex:
            ex.missing_returned_value = self.deconvert_cbuffers(*outbufs)
            raise
        else:
            return self.deconvert_cbuffers(res, *outbufs)

    def _get_trueargs(self, *args, **kwargs):
        bind=self._pyfunc_signature.bind(*args, **kwargs)
        bind.apply_defaults()
        return tuple(bind.arguments.values())

    @staticmethod
    def deconvert_cbuffers(*buffers:typing.Tuple[typing.Optional[_CtypesCData], ...]) -> (
            typing.Optional[
                typing.Union[
                    typing.Tuple[typing.Any, ...],
                    typing.Any]
            ]):
        """
        convert to python object from ctypes.buffers.
        If buffer is None, skip that buffer.
        return:
            len>1: tuple
            len=1: python object
            len=0: None
        """
        res=tuple(_convert_from_ctype(x) for x in buffers if x is not None)
        if len(res) > 1:
            return res
        if len(res) == 1:
            return res[0]
        return None

class _CWrapperClass:
    """ generate "decorator" class """
    # Note:
    #     in Windows, LoadLibrary cannot load uninstalled dll.
    #     We need to call `os.add_dll_directory` each "PATH".
    if os.name == "nt":
        for p in os.environ["PATH"].split(os.pathsep):
            if p:
                # Note: ignore invalied path.
                try:
                    os.add_dll_directory(p)
                except FileNotFoundError:
                    pass
                except OSError as e:
                    import errno
                    if e.errno not in {errno.EINVAL}:
                        raise
    def __init__(self, sopath: typing.Union[str, ctypes.CDLL],
                 funcname_converter: typing.Callable[[typing.Any], str]=str,
                 returnmode:ReturnMode=TakeInt(),
                 ):
        self.cdll = (sopath if isinstance(sopath, ctypes.CDLL) else
                     ctypes.cdll.LoadLibrary(sopath))
        self.funcname_converter = funcname_converter
        self.default_returnmode = returnmode
    def __call__(self, *args, **kwargs):
        return self._decorate(*args, **kwargs)
    def _decorate(self, *csignature,
                 force_funcname:typing.Optional[typing.Callable[[str], str]]=None,
                 returnmode: typing.Optional[ReturnMode]=None,
                 ):
        if returnmode is None:
            returnmode = self.default_returnmode
        def inner(func):
            python_funcname = func.__name__
            c_lang_funcname = (self.funcname_converter(python_funcname)
                               if force_funcname is None else force_funcname)
            funcptr=getattr(self.cdll, c_lang_funcname)
            w=functools.wraps(func)
            return w(_CWrapperCore(funcptr, func,
                                  *map(ArgumentMode.auto_in, csignature),
                                  returnmode=ReturnMode.auto_instance(returnmode),
                                  ))
        return inner

def CWrapper(sopath: typing.Union[str, ctypes.CDLL],
             funcname_converter : typing.Callable[[typing.Any], str]=str,
             returnmode : ReturnMode=TakeInt()) -> typing.Callable[
                 ..., # TODO: overwrite correct type (any length _CtypesCData)
                 typing.Callable[
                     [typing.Callable[_ParamSpec, _TypeVar]],
                     (typing.Callable[_ParamSpec, _TypeVar]),
                 ],
             ]:
    """
    To forward type annotation.
    usage:
        foowrapper=CWrapper("libfoo.so")
        @foowrapper(c_uint16, c_uint32, Out(ReturnType))
        func(a:ArgType1, b:ArgType2) -> ReturnType: ...
    """
    return _CWrapperClass(sopath, funcname_converter, returnmode)
