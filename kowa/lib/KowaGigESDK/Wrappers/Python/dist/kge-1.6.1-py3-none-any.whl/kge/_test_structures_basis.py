# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import unittest
from _testtools import gccso
from _testtools import strip_indent

import os
import sys

import ctypes
from ctypes import (
    c_int, c_uint,
    c_int8, c_uint8,
    c_int16, c_uint16,
    c_int32, c_uint32,
    c_int64, c_uint64,
    c_char,
    c_float,
    c_double,
    c_bool,
    c_void_p,
)

import cwrapper
from cwrapper import (
    CWrapper,
    CWrapperError,
    # ArgumentMode section
    ArgumentMode,
    In,
    Out,
    InRef,
    InExpression,
    OutExpression,
    InConvert,
    InRefConvert,
    InConstant,
    # ReturnMode section
    ReturnMode,
    Take,
    TakeInt,
    Ignore,
    ErrorCode,
    IntErrorCode,
    Boolean,
)

import structures
import typing

def _removeprefix(prefix: str) -> typing.Callable[[str], str]:
    """
    Return function as,
    remove the "prefix" pattern from input string.
    e.g. prefix="A"
        "Atest" -> "test"
        "test" -> ValueError
        "testA" -> ValueError
    """
    def inner(s:str) -> str:
        if not s.startswith(prefix):
            raise ValueError()
        return s[len(prefix):]
    return inner


class TestIpv4_t(unittest.TestCase):
    sopath=gccso("""
    #include <stdint.h>
    union inet {
        struct u8x4 {
            uint8_t a,b,c,d;
        }x4;
        uint32_t addr;
    };
    void split(int*a, int*b, int*c, int*d, union inet ipaddr){
        *a=ipaddr.x4.a;
        *b=ipaddr.x4.b;
        *c=ipaddr.x4.c;
        *d=ipaddr.x4.d;
    }
    void merge(int a, int b, int c, int d, union inet* ipaddr){
        ipaddr->x4.a = a;
        ipaddr->x4.b = b;
        ipaddr->x4.c = c;
        ipaddr->x4.d = d;
    }
    """)
    wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.Ignore)
    @staticmethod
    @wrapper(Out(c_int), Out(c_int), Out(c_int), Out(c_int), structures.ipv4_t)
    def split(ip) -> typing.Tuple[int, int, int, int]: pass
    @wrapper(c_int, c_int, c_int, c_int, Out(structures.ipv4_t))
    def merge(a, b, c, d) -> structures.ipv4_t: pass

    def test_split1(self):
        self.assertEqual(self.split("1.2.3.4"), (1,2,3,4))
    def test_split2(self):
        value=+1*256**3 +2*256**2 +3*256**1 +4*256**0
        self.assertEqual(self.split(value), (1,2,3,4))
    def test_merge1(self):
        self.assertEqual(self.merge(5,6,7,8), "5.6.7.8")

    class WrapStruct(ctypes.Structure):
        _fields_ = [
            ("ip_native", structures.ipv4_t),
        ]
        ip: str = structures._getsetproperty(structures.ipv4_t, "ip_native")
    wrapper_remove_wrap=cwrapper.CWrapper(sopath, _removeprefix("wrap_"), returnmode=ReturnMode.Ignore)

    @wrapper_remove_wrap(Out(c_int), Out(c_int), Out(c_int), Out(c_int), WrapStruct)
    def wrap_split(ip) -> typing.Tuple[int, int, int, int]: pass
    @wrapper_remove_wrap(c_int, c_int, c_int, c_int, Out(WrapStruct))
    def wrap_merge(a, b, c, d) -> WrapStruct: pass
    def test_wrap_split(self):
        s=self.WrapStruct()
        s.ip="1.2.3.4"
        self.assertEqual(self.wrap_split(s), (1,2,3,4))
    def test_wrap_merge(self):
        s=self.wrap_merge(5,6,7,8)
        self.assertEqual(s.ip, "5.6.7.8")

if __name__=="__main__":
    unittest.main()
