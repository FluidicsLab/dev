# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import typing
from logging import getLogger

import ctypes
from . import cwrapper
from . import _loadcore

logger = getLogger(__name__)

def _camelCase2PascalCase(
        postconverter: typing.Callable[[str], str]=str) -> typing.Callable[[str], str]:
    """
    camelCase -> PascalCase.
    """
    # escape case
    # e.g. "__funcname" -> "funcname"
    # e.g. "test__funcname" -> "funcname"
    # e.g. "test__test__funcname" -> "funcname"
    def inner(funcname: str) -> str:
        if "__" in funcname:
            return funcname.split("__")[-1]
        assert funcname[0] in string.ascii_lowercase, (
            f"python-funcname requires camelCase, not PascalCase.({funcname})"
        )
        pascalname=f"{funcname[0].upper()}{funcname[1:]}"
        return postconverter(pascalname)
    return inner

callwrapper = cwrapper.CWrapper(_loadcore.dll,
                                str,
                                cwrapper.ReturnMode.Ignore())

#void WINAPI GEVGetErrorString(WORD error_code, char errorstring[128]) {
@callwrapper(ctypes.c_uint16, cwrapper.Out(ctypes.c_char*128))
def GEVGetErrorString(error_code: int) -> str:
    ... # type:ignore

class GEVError(cwrapper.CWrapperError):
    """ wrapped KowaGigEVisionLib C lang SDK's error """
    # Note: for static program analysis(pylint/mypy)
    GEV_STATUS_SUCCESS = 0x0000
    GEV_STATUS_PACKET_RESEND = 0x0100
    GEV_STATUS_NOT_IMPLEMENTED = 0x8001
    GEV_STATUS_INVALID_PARAMETER = 0x8002
    GEV_STATUS_INVALID_ADDRESS = 0x8003
    GEV_STATUS_WRITE_PROTECT = 0x8004
    GEV_STATUS_BAD_ALIGNMENT = 0x8005
    GEV_STATUS_ACCESS_DENIED = 0x8006
    GEV_STATUS_BUSY = 0x8007
    GEV_STATUS_LOCAL_PROBLEM = 0x8008
    GEV_STATUS_MSG_MISMATCH = 0x8009
    GEV_STATUS_INVALID_PROTOCOL = 0x800A
    GEV_STATUS_NO_MSG = 0x800B
    GEV_STATUS_PACKET_UNAVAILABLE = 0x800C
    GEV_STATUS_DATA_OVERRUN = 0x800D
    GEV_STATUS_INVALID_HEADER = 0x800E
    GEV_STATUS_WRONG_CONFIG = 0x800F
    GEV_STATUS_PACKET_NOT_YET_AVAILABLE = 0x8010
    GEV_STATUS_PACKET_AND_PREV_REMOVED_FROM_MEMORY = 0x8011
    GEV_STATUS_PACKET_REMOVED_FROM_MEMORY = 0x8012
    GEV_STATUS_NO_REF_TIME1 = 0x8013
    GEV_STATUS_PACKET_TEMPORARILY_UNAVAILABLE = 0x8014
    GEV_STATUS_OVERFLOW = 0x8015
    GEV_STATUS_ACTION_LATE = 0x8016
    GEV_STATUS_ERROR = 0x8FFF
    GEV_STATUS_CAMERA_NOT_INIT = 0xC001
    GEV_STATUS_CAMERA_ALWAYS_INIT = 0xC002
    GEV_STATUS_CANNOT_CREATE_SOCKET = 0xC003
    GEV_STATUS_SEND_ERROR = 0xC004
    GEV_STATUS_RECEIVE_ERROR = 0xC005
    GEV_STATUS_CAMERA_NOT_FOUND = 0xC006
    GEV_STATUS_CANNOT_ALLOC_MEMORY = 0xC007
    GEV_STATUS_TIMEOUT = 0xC008
    GEV_STATUS_SOCKET_ERROR = 0xC009
    GEV_STATUS_INVALID_ACK = 0xC00A
    GEV_STATUS_CANNOT_START_THREAD = 0xC00B
    GEV_STATUS_CANNOT_SET_SOCKET_OPT = 0xC00C
    GEV_STATUS_CANNOT_OPEN_DRIVER = 0xC00D
    GEV_STATUS_HEARTBEAT_READ_ERROR = 0xC00E
    GEV_STATUS_EVALUATION_EXPIRED = 0xC00F
    GEV_STATUS_GRAB_ERROR = 0xC010
    GEV_STATUS_DRIVER_READ_ERROR = 0xC011
    GEV_STATUS_XML_READ_ERROR = 0xC012
    GEV_STATUS_XML_OPEN_ERROR = 0xC013
    GEV_STATUS_XML_FEATURE_ERROR = 0xC014
    GEV_STATUS_XML_COMMAND_ERROR = 0xC015
    GEV_STATUS_GAIN_NOT_SUPPORTED = 0xC016
    GEV_STATUS_EXPOSURE_NOT_SUPPORTED = 0xC017
    GEV_STATUS_CANNOT_GET_ADAPTER_INFO = 0xC018
    GEV_STATUS_ERROR_INVALID_HANDLE = 0xC019
    GEV_STATUS_CLINK_SET_BAUD = 0xC01A
    GEV_STATUS_CLINK_SEND_BUFFER_FULL = 0xC01B
    GEV_STATUS_CLINK_RECEIVE_BUFFER_NO_DATA = 0xC01C
    GEV_STATUS_FEATURE_NOT_AVAILABLE = 0xC01D
    GEV_STATUS_MATH_PARSER_ERROR = 0xC01E
    GEV_STATUS_FEATURE_ITEM_NOT_AVAILABLE = 0xC01F
    GEV_STATUS_NOT_SUPPORTED = 0xC020
    GEV_STATUS_GET_URL_ERROR = 0xC021
    GEV_STATUS_READ_XML_MEM_ERROR = 0xC022
    GEV_STATUS_XML_SIZE_ERROR = 0xC023
    GEV_STATUS_XML_ZIP_ERROR = 0xC024
    GEV_STATUS_XML_ROOT_ERROR = 0xC025
    GEV_STATUS_XML_FILE_ERROR = 0xC026
    GEV_STATUS_DIFFERENT_IMAGE_HEADER = 0xC027
    GEV_STATUS_XML_SCHEMA_ERROR = 0xC028
    GEV_STATUS_XML_STYLESHEET_ERROR = 0xC029
    GEV_STATUS_FEATURE_LIST_ERROR = 0xC02A
    GEV_STATUS_ALREADY_OPEN = 0xC02B
    GEV_STATUS_TEST_PACKET_DATA_ERROR = 0xC02C
    GEV_STATUS_FEATURE_NOT_FLOAT = 0xC02D
    GEV_STATUS_FEATURE_NOT_INTEGER = 0xC02E
    GEV_STATUS_XML_DLL_NOT_FOUND = 0xC02F
    GEV_STATUS_XML_NOT_INIT = 0xC030
    GEV_STATUS_NOT_SAME_SUBNET = 0xC031
    GEV_STATUS_GET_MANIFEST_TABLE_ERROR = 0xC032
    GEV_STATUS_DEPRECATED = 0xC033
    GEV_STATUS_BUFFERS_NOT_INIT = 0xC034
    #GEV_STATUS_BUFFER_TOO_SMALL = 0xC035
    GEV_STATUS_INVALID_ARGUMENT = 0xC036
    #GEV_STATUS_ARGUMENT_IS_NULL = 0xC037
    GEV_STATUS_FEATURE_WRONG_TYPE = 0xC038
    GEV_STATUS_INVALID_OPERATION = 0xC039
    GEV_STATUS_UNDECIDED_PORT = 0xC03A
    def error_to_string(self) -> str:
        return GEVGetErrorString(self.error_code)

class GEVGrabError(GEVError):
    pass

GEVError.add_raisetype({
    0: None,
    GEVError.GEV_STATUS_GRAB_ERROR: GEVGrabError,
})
