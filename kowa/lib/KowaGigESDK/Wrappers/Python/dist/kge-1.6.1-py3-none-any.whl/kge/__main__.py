# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import sys
import logging

from .demo import demo

# setting logger
logger = logging.getLogger(__package__)
logger.setLevel(logging.DEBUG)

class CustomFormatter(logging.Formatter):
    """ logging Customed formatter. """
    _baseformat = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    _colorreset = "\x1b[0m"
    _formats = {
         logging.DEBUG    : f"\x1b[02m{_baseformat}{_colorreset}",
         logging.INFO     : f"\x1b[39m{_baseformat}{_colorreset}",
         logging.WARNING  : f"\x1b[33m{_baseformat}{_colorreset}",
         logging.ERROR    : f"\x1b[31;1m{_baseformat}{_colorreset}",
         logging.CRITICAL : f"\x1b[41m{_baseformat}{_colorreset}",
    } if sys.stderr.isatty() else {}
    _formatters = {
        level : logging.Formatter(fmt)
        for level, fmt in _formats.items()
    }
    _default_formatter = logging.Formatter(_baseformat)
    def format(self, record):
        formatter = self._formatters.get(record.levelno, self._default_formatter)
        return formatter.format(record)

ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(CustomFormatter())
logger.addHandler(ch)

sys.exit(demo())
