# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import unittest
from _testtools import gccso
from _testtools import strip_indent

import os
import sys

import ctypes
import _ctypes
from ctypes import (
    c_int, c_uint,
    c_int8, c_uint8,
    c_int16, c_uint16,
    c_int32, c_uint32,
    c_int64, c_uint64,
    c_char,
    c_float,
    c_double,
    c_bool,
    c_void_p,
)

import cwrapper
from cwrapper import (
    CWrapper,
    CWrapperError,
    # ArgumentMode section
    ArgumentMode,
    In,
    Out,
    InRef,
    InExpression,
    OutExpression,
    InConvert,
    InRefConvert,
    InConstant,
    # ReturnMode section
    ReturnMode,
    Take,
    TakeInt,
    Ignore,
    ErrorCode,
    IntErrorCode,
    Boolean,
)


class TestCWrapperBasic(unittest.TestCase):
    def test_wrap_basic(self):
        sopath=gccso("int func(){ return 42;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper()
        def func(): pass
    def test_wrap_call(self):
        sopath=gccso("int func(){ return 42;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper()
        def func(): pass
        func()
    def test_wrap_retcode(self):
        sopath=gccso("int func(){ return 42;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper()
        def func(): pass
        self.assertEqual(42, func())
    def test_unknown_function(self):
        sopath=gccso("int func(){ return 42;}")
        wrapper=cwrapper.CWrapper(sopath)
        with self.assertRaises(AttributeError):
            # undefined symbol. raise Error.
            @wrapper()
            def unknown(): ...
    def test_repr(self):
        sopath=gccso("int func(){ return 42;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper()
        def func(): pass
        self.assertRegex(repr(func), "func")


class TestCWrapperArgs(unittest.TestCase):
    def test_args_and_return(self):
        sopath=gccso("int add(int a, int b){ return a+b;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(c_int, c_int)
        def add(a,b): ...
        self.assertEqual(add(2,5), 7)
    def test_wrong_argument_count(self):
        sopath=gccso("int add(int a, int b){ return a+b;}")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(c_int, c_int)
        def add(a,b): ...
        with self.assertRaises(TypeError):
            add(4, 5, 6)


class TestCWrapperReturns(unittest.TestCase):
    sopath=gccso("""
    void action(){}
    int ret42(){ return 42;}
    int take(int a){ return a;}
    int equals(int a, int b){ return a==b;}
    int returnzero(){ return 0;}
    """)
    def test_return_ignore1(self):
        # mode specify at *CWrapper init*.
        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.Ignore)
        @wrapper()
        def action(): ...
        self.assertIsNone(action())
    def test_return_ignore2(self):
        # mode specify at *decorate*.
        wrapper=cwrapper.CWrapper(self.sopath)
        @wrapper(returnmode=ReturnMode.Ignore)
        def action(): ...
        self.assertIsNone(action())
    def test_return_ignore3(self):
        wrapper=cwrapper.CWrapper(self.sopath)
        @wrapper(returnmode=ReturnMode.Ignore)
        def ret42(): ...
        self.assertIsNone(ret42())

    # error test
    class Error1(cwrapper.CWrapperError):
        pass
    class Error1_1(Error1):
        pass
    class Error1_1_1(Error1_1):
        pass
    class Error1_2(Error1):
        pass
    Error1.add_raisetype({
        4:None, # 4 is no error. not 0, 0 is error.
        5:Error1_1,
        6:Error1_1_1,
        7:Error1_2,
    })
    error_test_wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.IntErrorCode(Error1))

    def test_error_noerror(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        self.assertIsNone(take(4))
    def test_error_error3(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        with self.assertRaises(self.Error1):
            take(3)
    def test_error_error5(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        with self.assertRaisesRegex(self.Error1_1, "5"):
            take(5)
    def test_error_error6(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        with self.assertRaisesRegex(self.Error1_1_1, "6"):
            take(6)
    def test_error_error7(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        with self.assertRaisesRegex(self.Error1_2, "7"):
            take(7)
    def test_error_error8(self):
        @self.error_test_wrapper(c_int)
        def take(ecode): ...
        with self.assertRaisesRegex(self.Error1, "8"):
            take(8)

    def test_error_boolean(self):
        class Error(cwrapper.CWrapperError):
            pass
        Error.add_raisetype({0:None}) # do not raise Error at 0, raise Error at None.
        # raise if False.
        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.Boolean(Error))
        @wrapper()
        def returnzero(): ...
        with self.assertRaises(Error):
            returnzero()
    def test_error_boolean_errorhandle(self):
        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(c_int)
        def take(ecode): ... # get errorcode.

        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.Boolean(self.Error1, lambda:take(6)))
        @wrapper()
        def returnzero(): ...

        with self.assertRaisesRegex(self.Error1, "6"):
            # returnzero()
            #     -> False
            #     -> error handler "lambda:take(6)" (return: 6) called.
            #     -> self.Error1.raise_iferror(6)
            #     -> raise Error1(6) codename: "SIX"
            returnzero()

    def test_error_boolean_errorhandle_noerror(self):
        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(c_int)
        def take(ecode): ... # get errorcode.

        wrapper=cwrapper.CWrapper(self.sopath, returnmode=ReturnMode.Boolean(self.Error1, lambda:take(4)))
        @wrapper()
        def returnzero(): ...

        # returnzero()
        #     -> False
        #     -> error handler "lambda:take(4)" (return: 4) called.
        #     -> self.Error1.raise_iferror(4)
        #     -> noerror
        returnzero()

class TestCWrapperSignature(unittest.TestCase):
    def test_out1(self):
        sopath=gccso("""
        int div(int divided, int by, int* result){
            if(by == 0) return 0; // False
            *result = divided/by;
            return 1;
        }""")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(c_int, c_int, Out(c_int), returnmode=ReturnMode.Take(c_bool))
        def div(divided, by): ... # -> tuple[bool, int]

        self.assertEqual(div(13, 3), (True, 4))
    def test_out2(self):
        sopath=gccso("""
        int div(int divided, int by, int* result){
            if(by == 0) return 0; // False
            *result = divided/by;
            return 1;
        }""")
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(c_int, c_int, Out(c_int), returnmode=ReturnMode.Take(c_bool))
        def div(divided, by): ... # -> tuple[bool, int]
        self.assertFalse(div(13, 0)[0])
    def test_inref(self):
        sopath=gccso("""
        void mystrcat(char* s1, const char* s2){
            while(*s1++);
            s1--;
            while(*s1++=*s2++);
        }
        """)
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(InRef(c_char*0), c_char*0)
        def mystrcat(s1, s2): ...
        buf=(c_char*16)(*b"init")
        adder="adder"
        mystrcat(buf, adder)
        self.assertEqual(buf.raw.decode().split("\x00",1)[0], "initadder")
    def test_outstring(self):
        sopath=gccso("""
        void mystrcpy(char* dst, const char* src){
            while(*dst++=*src++);
        }
        """)
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.Ignore)
        @wrapper(Out(c_char*32), c_char*0)
        def mystrcpy(src): ... # -> dst
        self.assertEqual(mystrcpy("teststring"), "teststring")
    def test_convert(self):
        sopath=gccso("""int take(int a){return a;}""")
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(InConvert(c_int, lambda x:x*x))
        def take(a): ...
        self.assertEqual(take(5), 25)
    def test_constant(self):
        sopath=gccso("""int take(int a){return a;}""")
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(InConstant(c_int, 42))
        def take(): ...
        self.assertEqual(take(), 42)
    def test_expression(self):
        sopath=gccso("""int take(int a){return a;}""")
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        def inc():
            i=-1
            def inner():
                nonlocal i
                i+=1
                return i
            return inner
        @wrapper(InExpression(c_int, inc()))
        def take(): ...
        self.assertEqual(take(), 0)
        self.assertEqual(take(), 1)
        self.assertEqual(take(), 2)
    def test_expression2(self):
        sopath=gccso("""int add(int a, int b){return a+b;}""")
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(c_int, InExpression(c_int, lambda x:x*x))
        def add(a): ... # a + a*a
        self.assertEqual(add(3), 12)
    def test_all(self):
        sopath=gccso("""
        int allstar(int a, int b, int* ab_add,
                int c, int d, int* cd_sub,
                int return_value){
            *ab_add=a+b;
            *cd_sub=c-d;
            return return_value;
        }""")
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(c_int, c_int, Out(c_int), c_int, c_int, Out(c_int), InExpression(c_int, lambda *args:sum(args)))
        def allstar(a, b, c, d): ... # -> tuple["return", "ab_add", "cd_sub"]
        (ret, abadd, cdsub)= allstar(6, 7, 8, 9) # return_value -> sum((6,7,8,9)) -> 30
        self.assertEqual((ret, abadd, cdsub), (30, 13, -1))

class TestCWrapperStruct(unittest.TestCase):
    # test struct pointer(In/Out)
    class Struct(ctypes.Structure):
        _fields_ = [
            ("a", c_int),
            ("b", c_int),
            ("string", c_char*32),
        ]
    StructCHeader = """
    typedef struct tagStruct{
        int a;
        int b;
        char string[32];
    }Struct;
    """
    @staticmethod
    def to_string(buffer: bytes):
        b=buffer.split(b"\x00", 1)[0]
        return b.decode()
    def test_out(self):
        sopath=gccso(self.StructCHeader + """
        #include<stdio.h>
        void dumpadd(int a, int b, Struct* s){
            s->a = a;
            s->b = b;
            sprintf(s->string, "%d", a+b);
        }
        """)
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.Ignore)
        @wrapper(c_int, c_int, Out(self.Struct))
        def dumpadd(a, b): ...
        s=dumpadd(123,234)
        self.assertEqual(s.a, 123)
        self.assertEqual(s.b, 234)
        self.assertEqual(self.to_string(s.string), "357")
    def test_in(self):
        sopath=gccso(self.StructCHeader + """
        int add(Struct* s){
            return s->a + s-> b;
        }
        """)
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.TakeInt)
        @wrapper(InRef(self.Struct))
        def add(s: self.Struct): ...
        s=self.Struct()
        s.a=15
        s.b=27
        self.assertEqual(add(s), 42)
    def test_convertin(self):
        sopath=gccso(self.StructCHeader + """
        #include<stdio.h>
        void dump(Struct* s, const char* format){
            sprintf(s->string, format, s->a, s->b);
        }
        """)
        wrapper=cwrapper.CWrapper(sopath, returnmode=ReturnMode.Ignore)
        Struct=self.Struct
        def addself(func):
            import functools
            return functools.partialmethod(func)
        class C:
            def __init__(self, a, b):
                self.s = Struct()
                self.s.a = a
                self.s.b = b
            @addself
            @wrapper(InRefConvert(Struct, lambda self:self.s), In(c_char*0))
            def dump(self, format: str): ...
        c=C(15, 30)
        c.dump("%d and %d")
        self.assertEqual(self.to_string(c.s.string), "15 and 30")


class TestFuncnameConvert(unittest.TestCase):
    sopath=gccso("""int APItake(int a){ return a;}""")
    def test_shortname(self):
        wrapper=cwrapper.CWrapper(self.sopath, funcname_converter=lambda s:"API"+s)
        @wrapper(c_int, returnmode=ReturnMode.TakeInt)
        def take(a: int): ...
        self.assertEqual(take(42), 42)
    def test_longname(self):
        wrapper=cwrapper.CWrapper(self.sopath, funcname_converter=lambda s:s[2:])
        @wrapper(c_int, returnmode=ReturnMode.TakeInt)
        def PYAPItake(a: int): ...
        self.assertEqual(PYAPItake(42), 42)
    def test_shortname_at_wrapping(self):
        wrapper=cwrapper.CWrapper(self.sopath)
        @wrapper(c_int, returnmode=ReturnMode.TakeInt, force_funcname="APItake")
        def func(a: int): ...
        self.assertEqual(func(42), 42)


class TestCallback(unittest.TestCase):
    action_only=gccso("""
    int action(int(*callback)(void)) { return callback();}
    """)
    def test_call(self):
        wrapper=cwrapper.CWrapper(self.action_only)
        @wrapper(_ctypes.CFuncPtr)
        def action(cb: callable): ...
        @ctypes.CFUNCTYPE(None)
        def callback(): pass
        action(callback)
    def test_call2(self):
        wrapper=cwrapper.CWrapper(self.action_only)
        @wrapper(_ctypes.CFuncPtr)
        def action(cb: callable): ...
        called = False
        @ctypes.CFUNCTYPE(None)
        def callback():
            nonlocal called
            called = True
        action(callback)
        self.assertTrue(called)
    def test_take(self):
        sopath=gccso("""
        int func(int(*callback)(int), int value) { return callback(value);}
        """)
        wrapper=cwrapper.CWrapper(sopath)
        @wrapper(_ctypes.CFuncPtr, c_int, returnmode=ReturnMode.TakeInt)
        def func(cb: callable, x: int): ...
        @ctypes.CFUNCTYPE(c_int, c_int)
        def callback(x): return x**2
        self.assertEqual(func(callback, 6), 36)


if __name__=="__main__":
    unittest.main()
