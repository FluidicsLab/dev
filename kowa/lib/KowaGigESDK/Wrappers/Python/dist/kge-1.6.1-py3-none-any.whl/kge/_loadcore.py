# (c) 2024 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import typing

import ctypes

from . import cwrapper
from . import _info

from logging import getLogger
logger = getLogger(__name__)

libname={
    "posix": "libKowaGigEVisionLib.so",
    "nt": "KowaGigEVisionLib.dll",
}[os.name]
dll = ctypes.cdll.LoadLibrary(libname)

# load only stabled function
try:
    __fpdllver = dll["GEVGetDllVersion"]
    __fpabiver = dll["GEVGetDllAbiVersion"]
except AttributeError:
    raise RuntimeError(f"'{libname}' is too old (<1.4.1).")

def GEVGetDllVersion() -> typing.Tuple[int, int, int]: # major, minor, micro
    vers = [ctypes.c_int() for _ in range(3)]
    pvers = [ctypes.byref(v) for v in vers]
    __fpdllver(*pvers)
    return tuple(v.value for v in vers)

def GEVGetDllAbiVersion() -> typing.Tuple[int, int, int]: # major, minor, micro
    vers = [ctypes.c_int() for _ in range(3)]
    pvers = [ctypes.byref(v) for v in vers]
    __fpabiver(*pvers)
    return tuple(v.value for v in vers)

_abiver = GEVGetDllAbiVersion()
_dllver = GEVGetDllVersion()
assert _info._version >= _abiver, (
    "{}: incorrect abi version {}, requires version {} or earlier.".format(
        libname, _abiver, _info._version,
    ))
assert _info._version <= _dllver, (
    "{}: incorrect dll version {}, requires version {} or later.".format(
        libname, _dllver, _info._version,
    ))

noreturn_callwrapper = cwrapper.CWrapper(
    dll, str, cwrapper.ReturnMode.Ignore)
