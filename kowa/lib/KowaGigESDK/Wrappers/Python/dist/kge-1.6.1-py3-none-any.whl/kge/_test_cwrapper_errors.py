# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import cwrapper
import unittest

import os
import sys




class CErrorBase(cwrapper.CWrapperError):
    pass
class CErrorDerived(CErrorBase):
    pass

class TestCWrapperError(unittest.TestCase):

    CErrorBase.add_raisetype({0:None}) # no error
    CErrorBase.add_raisetype({42:CErrorDerived}) # spesial error

    def test_no_raise(self):
        CErrorBase.raise_iferror(0)
    def test_raise(self):
        self.assertRaises(CErrorBase, CErrorBase.raise_iferror, 1)
    def test_spesial_raise(self):
        self.assertRaises(CErrorDerived, CErrorBase.raise_iferror, 42)


if __name__=="__main__":
    unittest.main()
