# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

_version = (1, 6, 1)
# "", "alpha2", "beta5", "rc6", "dev12", etc...
# see also: PEP 440
_releaselevel = ""
__version__ = (".".join(map(str, _version)) + (
    ("-" + _releaselevel) if _releaselevel else ""))
__author__ = "Kowa Optronics Co.,Ltd."
