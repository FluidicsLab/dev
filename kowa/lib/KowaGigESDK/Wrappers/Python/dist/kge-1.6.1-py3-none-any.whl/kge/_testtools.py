# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import sys
import os

import string
import subprocess
import getpass
from tempfile import gettempdir
import typing
import hashlib

def sha1sum(*args: str) -> str:
    """ strings to sha1 digest. """
    h=hashlib.sha1()
    for x in args:
        h.update(x.encode())
        h.update(b"\x00")
    return h.hexdigest()

def executer(*commandlines:str) -> None:
    s=subprocess.run(commandlines)
    if s.returncode != 0:
        raise Exception(s.returncode)

def create_if_need(fpath:str, create:typing.Callable[[str], typing.Any]) -> None:
    if not os.path.exists(fpath):
        create(fpath)

def getunique_by_user() -> str:
    return getpass.getuser()

def gettextfile(filepath: str) -> str:
    with open(filepath) as f:
        return f.read()

_tmpdir=os.path.join(gettempdir(), f"tmp.{getunique_by_user()}.{sha1sum(gettextfile(__file__))}")
os.makedirs(_tmpdir, mode=0o700, exist_ok=True)
def get_tempfile_path(fname:str):
    return os.path.join(_tmpdir, fname)

def create_file(fpath:str, data:str):
    with open(fpath, "w")as f:
        f.write(data)


def gccso(src:str, *commandlines: str) -> str:
    """
    compile src to .so library by gcc.
    If exists cache, skip compile.
    """
    implicit_commandlines=("gcc", "-shared", "-fPIC", "-std=c11")

    src_digest=sha1sum(src)
    src_path=get_tempfile_path(f"{src_digest}.c")
    create_if_need(src_path, lambda x:create_file(x, src))

    dst_digest=sha1sum(*implicit_commandlines, *commandlines, src_path)
    dst_path=get_tempfile_path(f"lib{dst_digest}.so")
    create_if_need(dst_path, lambda x:executer(*implicit_commandlines, *commandlines, src_path, "-o", x))

    return dst_path

def strip_indent(code:str) -> str:
    def get_indent(s):
        ss=s.lstrip(string.whitespace)
        if ss:
            return s[:-len(ss)]
        else:
            return s
    def remove_indent(indent:str):
        line=0
        def inner(s):
            nonlocal line
            line+=1
            if not s:
                return s
            if not s.startswith(indent):
                raise IndentationError(f"line {line}, requires indent: {repr(indent)}, {repr(s)}")
            return s.removeprefix(indent)
        return inner
    lines=code.splitlines()
    if not lines:
        return ""
    if lines[-1]:
        lines.append("") # insert final newline
    # minimum indent string (exclude blank lines.)
    min_indent=min(map(get_indent, filter(bool, lines)), key=len)
    striped_lines=map(remove_indent(min_indent), lines)
    return "\n".join(striped_lines)
