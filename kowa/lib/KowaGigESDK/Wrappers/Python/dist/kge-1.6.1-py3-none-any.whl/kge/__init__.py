# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import sys
assert sys.version_info >= (3, 6), "Use python 3.6 or newer"

# Note: not use "logging", because
#     "logging.info()" and "logger.info()" are similar.
#     prevent them typo.
from logging import getLogger

# enable escape sequence if windows.
# this setting needs earlier import other module.
from . import util as _util
if os.name == "nt":
    _util.enable_ansi_escape_sequence()

#pylint: disable=wrong-import-position

from ._info import (
    __version__,
    __author__,
)

from .structures import (
    FeatureList,
    FEATURE_PARAMETER,
    DEVICE_PARAM,
    ADAPTER_PARAM,
    ENUMERATE_ADAPTER,
    DISCOVERY,
    CONNECTION,
    CLINK_STATUS,
    CHANNEL_PARAMETER,
    IMAGE_HEADER,
    ACTION_KEYS,
)

from .functions import (
    init,
    initEx,
    discovery,
    enumerateAdapters,
    forceIp,
    checkDeviceStatus,
    issueActionCommandBroadcast,
    issueActionCommandAdapter,
    issueActionCommandBroadcastDirected,
    issueActionCommandAdapterDirected,
    getDllAbiVersion,
    getDllVersion,
)

from .geverror import (
    GEVError,
    GEVGrabError,
    GEVGetErrorString as getErrorString,
)

from .enum import (
    Type,
    AccessMode,
    Visibility,
    Sign,
    Representation,
    DisplayNotation,
    DiscoveryStatus,
    Access,
)

from .demo import demo

logger = getLogger(__name__)
