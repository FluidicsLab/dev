# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import sys

import typing
from logging import getLogger

import ctypes
import ctypes as _c

from .. import geverror
from .. import cwrapper
from .. import cwrapper as _cw
from .. import structures
from .. import functions
from . import _loadcore

logger = getLogger(__name__)

# Note:
#     for cwrapper.py type annotation to works,
#     you must use python3.10 or later.
if sys.version_info >= (3, 10):
    _TypeVar = typing.TypeVar('_TypeVar')
    _ParamSpec = typing.ParamSpec('_ParamSpec')
else:
    _TypeVar = typing.Any
    _ParamSpec = ...


callwrapper = _cw.CWrapper(_loadcore.dll,
                           functions._camelCase2PascalCase(lambda s:"Pwm"+s),
                           _cw.ReturnMode.ErrorCode(geverror.GEVError, _c.c_uint16))


_inConvertCameraToCameraNo = functions._OpenedCamera._inConvertSelfToCameraNo

@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32, _c.c_uint32, _c.c_uint32, _c.c_uint32)
def setParameter(camera: functions._OpenedCamera,
                 mode: int, delay: int, width: int, duty: int):
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo,
             _cw.Out(_c.c_uint32), _cw.Out(_c.c_uint32), _cw.Out(_c.c_uint32), _cw.Out(_c.c_uint32))
def getParameter(camera: functions._OpenedCamera) -> typing.Tuple[int, int, int, int]:
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _c.c_uint32, _c.c_uint32, _c.c_uint32, _c.c_uint32)
def setManualCtrl(camera: functions._OpenedCamera, enable: bool):
    return ... # type:ignore

@callwrapper(_inConvertCameraToCameraNo, _cw.Out(_c.c_uint32))
def getManualCtrl(camera: functions._OpenedCamera) -> bool:
    return ... # type:ignore
