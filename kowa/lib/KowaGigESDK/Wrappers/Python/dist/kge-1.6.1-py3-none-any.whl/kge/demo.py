# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import ctypes
import typing
from logging import getLogger

from . import structures
from . import functions
from . import geverror
from . import util

logger = getLogger(__name__)


# mock "import kge"
kge = util.MergeAttributes(structures, functions, geverror)

def _camera(camera):
    # delay load
    # Note: only demo() function uses numpy and cv2.
    import numpy as np # pylint: disable = import-outside-toplevel
    import cv2 # pylint: disable = import-outside-toplevel

    # setSchemaPath and initXml was implicitly called at init.
    with camera.initFilterDriver():
        with camera.openStreamChannel(0):

            camera.setPacketResend(1)

            camera.setFeatureInteger("GevSCPD", 500)
            camera.setFeatureInteger("ExposureTime", 5000)

            # test maximum achievable packet size
            max_packet_size = camera.testFindMaxPacketSize()
            logger.info("max_packet_size: %d", max_packet_size)

            width = camera.getFeatureInteger("Width")
            height = camera.getFeatureInteger("Height")
            pixel_format = camera.getFeatureInteger("PixelFormat")
            img_size = camera.getFeatureInteger("PayloadSize")
            logger.info("width: %d", width)
            logger.info("height: %d", height)
            logger.info("pixelFormat: %#010x", pixel_format)
            logger.info("pixelformat(bpp): %#04x", (pixel_format>>16)&0xff)
            logger.info("payloadsize: %d", img_size)

            if height == 0 or width == 0 or img_size == 0:
                logger.error("Image is empty.")
                return 2

            image_buffer = (ctypes.c_uint8*img_size)()
            dsize=(width*360//height, 360) # (w,h) to 360p

            logger.info("Start acquisiton")
            with camera.acquisitionStart(0):

                logger.info("Display image ...")
                frameno=-1
                while True:
                    frameno+=1
                    try:
                        img_header = camera.getImageBuffer(image_buffer)
                    except kge.GEVGrabError as e:
                        logger.error("frame %d: error %s", frameno, e)
                    else:
                        grabbed_img = np.ctypeslib.as_array(image_buffer).reshape(height,width)
                        display_img = cv2.resize(grabbed_img, dsize=dsize,
                                                 interpolation=cv2.INTER_AREA)
                        cv2.imshow("frame", display_img)
                        key = cv2.waitKey(1)
                        if key != -1:
                            logger.info("pressed key: %d", key)
                        if key in range(32, 128):
                            cv2.destroyAllWindows()
                            return None

def _device(dev):
    with kge.init(None, dev, 0, 1) as camera:
        logger.info("selected camera no: %s", camera.camera_no)
        return _camera(camera)

def demo(obj: typing.Optional[typing.Union[
             kge.DEVICE_PARAM,
             kge._OpenedCamera,
         ]] = None) -> typing.Optional[int]:
    if isinstance(obj, kge._OpenedCamera):
        return _camera(obj)
    if isinstance(obj, kge.DEVICE_PARAM):
        return _device(obj)

    dis = kge.discovery(1000)
    for i,d in enumerate(dis):
        logger.info("Device: %d", i)
        logger.info(d)

    if dis.Count == 0:
        logger.error("No GigE Device found.")
        return 1
    if dis.Count > 1:
        logger.info("Too GigE Device found(%s).", len(dis))
        logger.info("selected primary(0) device.")
    return _device(dis[0])

