# (c) 2024 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import ctypes

libname={
    "posix": "libKowaExternalControlLib.so",
    "nt": "KowaExternalControlLib.dll",
}[os.name]
dll = ctypes.cdll.LoadLibrary(libname)
