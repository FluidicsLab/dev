# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import os
import sys

import functools
import string
import typing
from logging import getLogger
import ctypes
import _ctypes

from ctypes import (
    c_int8, c_uint8,
    c_int16, c_uint16,
    c_int32, c_uint32,
    c_int64, c_uint64,
    c_int,
    c_char,
    c_float,
    c_double,
    c_bool,
    c_void_p,
    c_size_t,
)

from . import _loadcore

from .cwrapper import (
    CWrapper,
    CWrapperError,
    BoolLike,
    # ArgumentMode section
    ArgumentMode,
    In,
    Out,
    InRef,
    Buffer,
    InExpression,
    OutExpression,
    InConvert,
    InRefConvert,
    InConstant,
    # ReturnMode section
    ReturnMode,
    Take,
    TakeInt,
    Ignore,
    ErrorCode,
    IntErrorCode,
    Boolean,
)

from . import structures
from .structures import (
    ipv4_t,
    macaddr_t,
    FeatureList,
    FEATURE_PARAMETER,
    DEVICE_PARAM,
    ADAPTER_PARAM,
    ENUMERATE_ADAPTER,
    DISCOVERY,
    CONNECTION,
    CLINK_STATUS,
    CHANNEL_PARAMETER,
    IMAGE_HEADER,
    ACTION_KEYS,
)

from .geverror import (
    GEVError,
    GEVGrabError,
)

from .enum import (
    Type,
    AccessMode,
    Visibility,
    Sign,
    Representation,
    DisplayNotation,
    DiscoveryStatus,
    Access,
)

from . import util
from . import cwrapper
from . import _info

logger = getLogger(__name__)

libname={
    "posix": "libKowaGigEVisionLib.so",
    "nt": "KowaGigEVisionLib.dll",
}[os.name]

# Note:
#     for cwrapper.py type annotation to works,
#     you must use python3.10 or later.
if sys.version_info >= (3, 10):
    _TypeVar = typing.TypeVar('_TypeVar')
    _ParamSpec = typing.ParamSpec('_ParamSpec')
else:
    _TypeVar = typing.Any
    _ParamSpec = ...


def _removestring(remove: str) -> typing.Callable[[str], str]:
    """
    Return function as,
    remove the "remove" pattern from input string.
    e.g. remove="A"
        "Atest" -> "test"
        "testA" -> "test"
        "AtAeAsAtA" -> "test"
    """
    def inner(s:str) -> str:
        assert remove in s
        return "".join(s.split(remove))
    return inner

def _camelCase2PascalCase(
        postconverter: typing.Callable[[str], str]=str) -> typing.Callable[[str], str]:
    """
    camelCase -> PascalCase.
    """
    # escape case
    # e.g. "__funcname" -> "funcname"
    # e.g. "test__funcname" -> "funcname"
    # e.g. "test__test__funcname" -> "funcname"
    def inner(funcname: str) -> str:
        if "__" in funcname:
            return funcname.split("__")[-1]
        assert funcname[0] in string.ascii_lowercase, (
            f"python-funcname requires camelCase, not PascalCase.({funcname})"
        )
        pascalname=f"{funcname[0].upper()}{funcname[1:]}"
        return postconverter(pascalname)
    return inner


def _callable2instancemethod(func: typing.Callable[_ParamSpec, _TypeVar]) -> (
        typing.Callable[_ParamSpec, _TypeVar]):
    @functools.wraps(func)
    def inner(*args, **kwargs):
        return func(*args, **kwargs)
    return inner

callwrapper = CWrapper(libname,
                       _camelCase2PascalCase(lambda s:"GEV"+s),
                       ReturnMode.ErrorCode(GEVError, c_uint16))
cancamcallwrapper = CWrapper(libname,
                             _camelCase2PascalCase(lambda s:"CANCam"+s),
                             ReturnMode.ErrorCode(GEVError, c_uint16))
clinkcallwrapper = CWrapper(libname,
                            returnmode=ReturnMode.ErrorCode(GEVError, c_uint16))

class _EnterExitPair:
    def __init__(self, enterhook: typing.Callable[[], None], exithook: typing.Callable[[], None]):
        enterhook()
        self._exithook = exithook
    def __enter__(self) -> None:
        pass
    def __exit__(self, exc_type, exc_value, traceback):
        self._exithook()


class _OpenedCamera:
    # TODO: fix: bound function repr do not print signature.
    # TODO: change returned tuple -> namedtuple

    # know opened camera. only this process, at this python wrapper.
    # may fail to open, if already on other process.
    _opened_instance_table = {}
    @staticmethod
    def _getfrom_camera_no(camera_no):
        return __class__._opened_instance_table.get(camera_no)
    def _get_camera_no(self):
        # validate not closed
        if self.closed:
            raise ValueError("operate to closed camera")
        return self.camera_no
    _inConvertSelfToCameraNo = InConvert(c_uint8, _get_camera_no)

    def __init__(self, camera_no: int, connection: CONNECTION):
        self._opened_instance_table[camera_no] = self
        self.camera_no = camera_no
        self.connection = connection
        self.closed = False
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_value, traceback):
        if not self.closed:
            self.close()
    def __del__(self):
        if not self.closed:
            self.close()
    def __repr__(self):
        return f"<{self.__class__.__name__} {self}>"
    def __str__(self):
        return "".join([
            f"(cam_nr:{self.camera_no} {self.connection.IP_CANCam}",
            " *closed*" if self.closed else "",
            ")",
        ])

    def _decoclose(func: typing.Callable[_ParamSpec, _TypeVar]) -> (
            typing.Callable[_ParamSpec, _TypeVar]):
        @functools.wraps(func)
        def close(self):
            func(self)
            self.closed = True
            try:
                self._opened_instance_table.pop(self.camera_no)
            except KeyError:
                pass
        return close # type:ignore

    # ** General functions **
    @_callable2instancemethod
    @_decoclose
    @callwrapper(_inConvertSelfToCameraNo)
    def close(self) -> None:
        return ... # type:ignore

    # StreamChannel pair
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, ipv4_t, c_uint16, structures._ipv4_hostbyteorder_t)
    def __GEVOpenStreamChannel(self, adapterip: int, port: int, multicast: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def closeStreamChannel(self) -> None:
        return ... # type:ignore

    def openStreamChannel(self,
                          multicast: typing.Optional[str] = None, *,
                          port: typing.Optional[int] = None) -> _EnterExitPair:
        if port is None:
            port = self.connection.PortData

        return _EnterExitPair(lambda: self.__GEVOpenStreamChannel(
                                  self.connection.AdapterIP, port, multicast or 0),
                              self.closeStreamChannel)
    # FilterDriver pair
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def __GEVInitFilterDriver(self) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def closeFilterDriver(self) -> None:
        return ... # type:ignore

    def initFilterDriver(self) -> _EnterExitPair:
        return _EnterExitPair(self.__GEVInitFilterDriver,
                              self.closeFilterDriver)

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_uint32,
                 InExpression(c_uint32, lambda _,_1,b:len(b)),
                 InRef(c_uint32*0))
    def writeRegister(self, cmd: int, values: typing.Iterable[int]) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_uint32,
                 c_uint8,
                 OutExpression(c_uint32*0, lambda _,_1,l:(c_uint32*l)()))
    def readRegister(self, cmd: int, cnt: int) -> typing.Tuple[int, ...]: # values
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_uint32,
                 InExpression(c_uint32, lambda _,_1,b:len(b)),
                 c_uint8*0)
    def writeMemory(self, maddr: int, values: bytes) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_uint32,
                 c_uint32,
                 OutExpression(c_uint8*0, lambda _,_1,l:(c_uint8*l)()))
    def readMemory(self, maddr: int, cnt: int) -> bytes: # values
        return ... # type:ignore

    # *not suppert callback* setReadWriteMemoryCallback
    # *deprecated* getPixelPtr
    # *deprecated* setMemorySize
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def getMemorySize(self) -> int:
        return ... # type:ignore

    # *not suppert callback* setMessageChannelCallback

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32, c_uint8)
    def setReadWriteParameter(self, ack_timeout: int, retry_count: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32), Out(c_uint8))
    def getReadWriteParameter(self) -> typing.Tuple[int, int]:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_int8, c_uint32, c_uint32, c_uint32)
    def setNetConfig(self, enable_dhcp: bool, ip: int, subnet: int, gateway: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_int8), Out(c_uint32), Out(c_uint32), Out(c_uint32))
    def getNetConfig(self) -> typing.Tuple[int, int, int, int]:
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_int8), Out(c_int8))
    def getFilterDriverVersion(self) -> typing.Tuple[int, int]: # version_major, version_minor
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, CHANNEL_PARAMETER)
    def setChannelParameter(self, cparam: CHANNEL_PARAMETER) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(CHANNEL_PARAMETER))
    def getChannelParameter(self) -> CHANNEL_PARAMETER:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32)
    def setHeartbeatRate(self, heartbeat_rate: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def getHeartbeatRate(self) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def testPacket(self) -> int: # packet_size
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint8), Out(c_uint8))
    def getConnectionStatus(self) -> typing.Tuple[int, int]: # status, eval
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_double))
    def getTimeOneTick(self) -> float: # ttimes
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint8)
    def setDetailedLog(self, flags: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
    def getDetailedLog(self) -> int:
        return ... # type:ignore

    # note: not exists get API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32, c_uint32, c_uint32, c_uint32)
    def setActionCommand(self, device_key: int, group_key: int, group_mask: int,
                         action_time: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, InRef(ACTION_KEYS), c_uint64)
    def __GEVIssueActionCommandUnicast(self, keys, actiontime):
        return ... # type:ignore
    def issueActionCommandUnicast(self, keys: ACTION_KEYS,
                                  actiontime: typing.Optional[int] = None):
        if actiontime is None:
            actiontime = 0
        return self.__GEVIssueActionCommandUnicast(keys, actiontime)

        # TODO: datetime を受け付ける?

    # note: not exists get API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32)
    def setTraversingFirewallsInterval(self, interval: int) -> None:
        return ... # type:ignore

    # *windows only* enableFirewallException

    # ** xml functions **
    # not supported yet, because "FeatureList" is not supported yet.
    ## note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(ctypes.POINTER(ctypes.c_void_p)), Out(c_uint8))
    def __GEVGetFeatureList(self):
        return ... # maxLevel

    def getFeatureList(self) -> typing.Tuple[int]:
        (p, maxlevel) = self.__GEVGetFeatureList()
        return (FeatureList(p), maxlevel)

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(FEATURE_PARAMETER))
    def getFeatureParameter(self, feature_name: str) -> FEATURE_PARAMETER:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, c_int64)
    def setFeatureInteger(self, feature_name: str, value: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_int64))
    def getFeatureInteger(self, feature_name: str) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, c_char*0)
    def setFeatureString(self, feature_name: str, value: str) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, c_char*0)
    def __GEVGetFeatureString(self, feature_name: str, buf) -> None:
        return ... # type:ignore

    def getFeatureString(self, feature_name: str) -> str:
        f = self.getFeatureParameter(feature_name)
        buf = (ctypes.c_char * max(536, f.Length + 1))()
        self.__GEVGetFeatureString(feature_name, buf)
        r = cwrapper._convert_from_ctype(buf)
        del buf
        return r

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, BoolLike(c_uint32))
    def setFeatureBoolean(self, feature_name: str, value: bool) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(BoolLike(c_uint32)))
    def getFeatureBoolean(self, feature_name: str) -> bool:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, c_uint32)
    def setFeatureCommand(self, feature_name: str, value: int) -> None:
        return ... # type:ignore

    # note: why need this function??? Should it be "executeFeatureCommand" ?
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_uint32))
    def getFeatureCommand(self, feature_name: str) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0)
    def executeFeatureCommand(self, feature_name: str) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0,
                 c_char*0,
                 InExpression(c_int, lambda _,s,*_a:len(s)))
    def setFeatureEnumeration(self, feature_name: str, enum_name: str) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0,
                 Out(c_char*256),
                 InConstant(c_int, 256))
    def getFeatureEnumeration(self, feature_name: str) -> str:
        return ... # type:ignore

    # note: forward to getFeatureEnumerationName
    def getFeatureEnumerationNames(self, feature_name: str) -> typing.Tuple[
            str, ...]:
        def _infinity():
            i=0
            while True:
                yield i
                i += 1
        def _inner():
            for i in _infinity():
                e = self.getFeatureEnumerationName(feature_name, i)
                if not e:
                    break
                yield e
        return tuple(_inner())

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0,
                 c_uint8,
                 Out(c_char*256),
                 InConstant(c_int, 256))
    def getFeatureEnumerationName(self, feature_name: str, enum_index: int) -> str: # enum_name
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, c_double)
    def setFeatureFloat(self, feature_name: str, value: float) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_double))
    def getFeatureFloat(self, feature_name: str) -> float: # value
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_char*256), InConstant(c_int, 256))
    def getFeatureDisplayName(self, feature_name: str) -> str: # display_name
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_char*4096), InConstant(c_int, 4096))
    def getFeatureTooltip(self, feature_name: str) -> str: # tooltip_name
        return ... # type:ignore

    ## note: not exists get API
    #@_callable2instancemethod
    #@callwrapper(_inConvertSelfToCameraNo, c_char*0)
    #def setXmlFile(self, xml_name: str) -> None:
    #    return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def initXml(self) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0,
                 InExpression(c_uint32, lambda _,_1,b:len(b)),
                 InRef(c_uint8*0))
    def setFeatureRegister(self, feature_name: str, buffer: bytes) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0,
                 c_uint32,
                 OutExpression(c_uint8*0, lambda _,_1,l:(c_uint8*l)()))
    def getFeatureRegister(self, feature_name: str, length: int) -> c_uint8*0: # buffer
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_char*256), InConstant(c_int, 256))
    def getFeatureUnit(self, feature_name: str) -> str: # unit_name
        return ... # type:ignore

    # note: not exists set API
    # TODO: cast out parameter(c_uint8) to bool.
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_uint8))
    def getFeatureEnableStatus(self, feature_name: str) -> bool: #enable
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def getXmlSize(self) -> int: # size
        return ... # type:ignore

    # not supperted yet, because likely to mistake use char pointer pointer.
    # note: not exists set API
    # note:
    #     buf is `BYTE**` argument.
    #     If buf is `BYTE*`, this function can more simplify.
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, InRef(ctypes.POINTER(c_char)))
    def __GEVGetXmlFile(self, buf):
        return ... # type:ignore

    def getXmlFile(self) -> bytes:
        """
        Note:
            XML data often has CRLF.
            On windows, this codes will write CRCRLF.
            `with open("a.xml", "w") as f: f.write(camera.getXmlFile().decode())`
        Example:
            with open("a.xml", "wb") as f: f.write(camera.getXmlFile())
        """
        size = self.getXmlSize()
        buf = (c_char * size)()
        rbuf = ctypes.POINTER(buf._type_)(buf)
        self.__GEVGetXmlFile(rbuf)
        return buf.raw

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 c_char*0, c_uint8, Out(c_char*256), InConstant(c_int, 256))
    def getFeatureInvalidator(self, feature_name: str, index: int) -> str: # invalidator_name
        return ... # type:ignore

    # note: not exists set API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0, Out(c_char*256), InConstant(c_int, 256))
    def getFeaturePort(self, feature_name: str) -> str: # port_name
        return ... # type:ignore

    # note: not exists get API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_char*0)
    def setSchemaPath(self, schema_path: str) -> None:
        return ... # type:ignore

    # note: not exists get API
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 ctypes.c_byte*0,
                 InExpression(c_size_t, lambda _,l: len(l)))
    def setSchemaFromZip(self, schema_zip: bytes) -> None:
        return ... # type:ignore

    # not supperted, because cache files are disabled.
    ## note: not exists get API
    #@_callable2instancemethod
    #@callwrapper(_inConvertSelfToCameraNo, c_char*0)
    #def setXmlCacheDirectoryName(self, dname: str) -> None:
    #    return ... # type:ignore

    # ** Camera functions **

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, _ctypes.CFuncPtr)
    def __GEVSetAcquisitionCallback(self, callback) -> None:
        return ... # type:ignore
    def setAcquisitionCallback(self, callback:
                               typing.Optional[typing.Callable[
                                   ["_OpenedCamera", IMAGE_HEADER, c_uint8*0],
                                   None]]
                               ) -> None:
        @ctypes.CFUNCTYPE(None, c_uint8,
                          ctypes.POINTER(IMAGE_HEADER), ctypes.POINTER(ctypes.c_byte), c_size_t)
        def inner(self_camno, pimageheader, pdata, datalen):
            tdata = c_uint8 * datalen
            data = ctypes.cast(pdata, ctypes.POINTER(tdata))[0]
            header = ctypes.cast(pimageheader, ctypes.POINTER(IMAGE_HEADER))[0]
            callback(self, header, data)
        keeper = inner if callback is not None else None
        self.__GEVSetAcquisitionCallback(keeper)
        self._acquisition_callback_keeper = keeper



    # Acquisition pair
    # AcquisitionEx pair
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32)
    def __GEVAcquisitionStart(self, number_images_to_acquire: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32)
    def __GEVAcquisitionStartEx(self, number_images_to_acquire: int, image_size: int,
                                image_width: int, image_height: int, pixel_format: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def acquisitionStop(self) -> None:
        return ... # type:ignore

    def acquisitionStart(self, number_images_to_acquire: int) -> _EnterExitPair:
        return _EnterExitPair(lambda: self.__GEVAcquisitionStart(number_images_to_acquire),
                              lambda: self.acquisitionStop())
    def acquisitionStartEx(self, number_images_to_acquire: int, image_size: int,
                           image_width: int, image_height: int,
                           pixel_format: int) -> _EnterExitPair:
        return _EnterExitPair(
            lambda: self.__GEVAcquisitionStartEx(number_images_to_acquire, image_size, image_width,
                                                 image_height, pixel_format),
            lambda: self.acquisitionStop())


    # *deprecated* getImage

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(IMAGE_HEADER), Buffer(c_uint8*0))
    # TODO: add IMAGE_HEADER to Exception, when raised error.
    def getImageBuffer(self, buffer: c_uint8*0) -> IMAGE_HEADER:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(IMAGE_HEADER), Out(c_uint32))
    def getImageRingBuffer(self) -> typing.Tuple[IMAGE_HEADER, int]:
        # image_header, image_buffer_index
        return ... # type:ignore


    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32)
    def queueRingBuffer(self, image_buffer_index: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32, Buffer(c_uint8*0))
    def setRingBuffer(self, index: int, buffer: c_uint8*0) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo)
    def releaseRingBuffer(self) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo,
                 InExpression(c_uint32, lambda _,b: b._length_),
                 Buffer(c_uint8*0))
    def addRingBufferElement(self, buffer: c_uint8*0) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Buffer(c_uint8*0))
    def removeRingBufferElement(self, buffer: c_uint8*0) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint8)
    def setPacketResend(self, enable: bool) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
    def getPacketResend(self) -> bool:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32, c_int64, c_uint32, c_uint32)
    def packetResend(self, stream_channel: int, block_id: int,
                     first_packet_id: int, last_packet_id: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_double))
    def getImageFPS(self) -> float: # fps
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint32)
    def setBufferCount(self, count: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def getBufferCount(self) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
    def getFreeBufferCount(self) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint8, InConstant(c_void_p, None))
    def setSecureTransfer(self, enable: bool) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
    def getSecureTransfer(self) -> int:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint8)
    def setPacketsOutOfOrder(self, packets_out_of_order: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
    def getPacketsOutOfOrder(self) -> int:
        return ... # type:ignore


    # ** CANCam Camera functions **
    @property
    def cancam(self) -> None:
        """ this object is created only 1 time. """
        if not hasattr(self, "__cancam"):
            self.__cancam=self._CANCam(self)
        return self.__cancam

    class _CANCam:
        _inConvertSelfToCameraNo = InConvert(c_uint8, lambda self:self.parent._get_camera_no)
        def __init__(self, parent: "_OpenedCamera"):
            self.parent=parent

        # note: not exists set API
        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
        def getPixelFormat(self) -> int: # pixfmt
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint32), Out(c_uint32))
        def getMaxVideoWindow(self) -> typing.Tuple[int, int]: # max_width, max_height
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint32, c_uint32, c_uint32, c_uint32)
        def setVideoWindow(self, x_start: int, y_start: int, x_len: int, y_len: int) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo,
                           Out(c_uint32),
                           Out(c_uint32),
                           Out(c_uint32),
                           Out(c_uint32))
        def getVideoWindow(self) -> typing.Tuple[int, int, int, int]:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint8)
        def setGain(self, gain: int) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
        def getGain(self) -> int:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint8), Out(c_uint8))
        def getGainMinMax(self) -> typing.Tuple[int, int]: # gain_min, gain_max
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint8)
        def setGainAuto(self, on_off: bool) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint32)
        def setExposureTime(self, exposure_time) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint32))
        def getExposureTime(self) -> int:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint32), Out(c_uint32))
        def getExposureTimeMinMax(self) -> typing.Tuple[int, int]: # exposure_min, exposure_max
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, Out(c_uint8))
        def setExposureTimeAuto(self, on_off: bool) -> int:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint32, c_uint8)
        def setLut(self, index: int, value: int) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @cancamcallwrapper(_inConvertSelfToCameraNo, c_uint32, Out(c_uint8))
        def getLut(self, index: int) -> int:
            return ... # type:ignore

    # ** Camera Link functions **
    @property
    def clinkserial(self) -> None:
        """ this object is created only 1 time. """
        if not hasattr(self, "__clinkserial"):
            self.__clinkserial=self._CLinkSerial(self)
        return self.__clinkserial

    class _CLinkSerial:
        _inConvertSelfToCameraNo = InConvert(c_uint8, lambda self:self.parent._get_camera_no)
        def __init__(self, parent: "_OpenedCamera"):
            self.parent=parent

        @_callable2instancemethod
        @clinkcallwrapper(_inConvertSelfToCameraNo, c_uint32,
                          force_funcname="InitClinkSerial")
        def init(self, baud: int) -> None:
            return ... # type:ignore

        @_callable2instancemethod
        @clinkcallwrapper(_inConvertSelfToCameraNo, Out(CLINK_STATUS),
                          force_funcname="GetClinkStatus")
        def getStatus(self) -> CLINK_STATUS: # status
            return ... # type:ignore

        @_callable2instancemethod
        @clinkcallwrapper(_inConvertSelfToCameraNo,
                          InExpression(c_uint32, lambda _,b:b._length_), c_uint8*0,
                          force_funcname="SendClink")
        def send(self, send_buffer: c_uint8*0) -> None:
            return ... # type:ignore

        # TODO: change to return type. tuple[buffer, count] -> bytes
        @_callable2instancemethod
        @clinkcallwrapper(_inConvertSelfToCameraNo, c_uint32,
                          OutExpression(c_uint8*0, lambda _,b:(c_uint8*b._length_)()),
                          Out(c_uint32),
                          force_funcname="ReceiveClink")
        def receive(self, buffer_length: int) -> typing.Tuple[c_uint8*0, int]:
            # recv_buffer, recv_count
            return ... # type:ignore


    # ** Test functions **
    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, c_uint8, c_uint32, c_uint32)
    def testPacketResend(self, on_off: bool, packet_number: int, count: int) -> None:
        return ... # type:ignore

    @_callable2instancemethod
    @callwrapper(_inConvertSelfToCameraNo, Out(c_uint16), c_uint16, c_uint16, c_uint16)
    def __GEVTestFindMaxPacketSize(self, size_min: int, size_max: int, size_step: int) -> int:
        # packet_size
        return ... # type:ignore

    def testFindMaxPacketSize(self,
                              size_min: typing.Optional[int] = None,
                              size_max: typing.Optional[int] = None,
                              size_step: typing.Optional[int] = None) -> int:
        if (
                size_min is None or
                size_max is None or
                size_step is None or
                False):
            try:
                f_param = self.getFeatureParameter("GevSCPSPacketSize")
            except GEVError:
                f_param = object()
                f_param.Min = 0
                f_param.Max = 20000
                f_param.Min = 4
            size_min  = f_param.Min if (
                size_min  is None and f_param.Min != -1) else 0
            size_max  = f_param.Max if (
                size_max  is None and f_param.Max != -1) else 20000
            size_step = f_param.Inc if (
                size_step is None and f_param.Inc != +1) else 4
        return self.__GEVTestFindMaxPacketSize(size_min, size_max, size_step);





# ** General functions **
@callwrapper(Out(c_uint8), InRef(CONNECTION), InConstant(c_void_p, None), c_uint8, c_uint8)
def __GEVInitEx(
        connection: typing.Union[CONNECTION, DEVICE_PARAM],
        save_xml: int,
        open_mode: int) -> int:
    return ... # type:ignore

def initEx(
        connection: typing.Union[CONNECTION, DEVICE_PARAM],
        save_xml: bool = False,
        open_mode: typing.Union[Access, int] = Access.exclusive,
) -> _OpenedCamera:
    if isinstance(connection, CONNECTION):
        con = CONNECTION.from_buffer_copy(connection)
    elif isinstance(connection, DEVICE_PARAM):
        con = connection.toConnection()
    else:
        raise TypeError(
            f"connection must be CONNECTION or DEVICE_PARAM, "
            f"not {connection.__class__.__name__}"
        )
    camera_no = __GEVInitEx(con, save_xml, open_mode)
    camera = _OpenedCamera(camera_no, con)
    try:
        camera.initXml()
        return camera
    except:
        camera.close()
        raise

def _decoinit(*posthooks: typing.Callable[[_OpenedCamera], typing.Optional[typing.Any]]) -> (
        typing.Callable[
            [typing.Callable[_ParamSpec, _TypeVar]],
            (typing.Callable[_ParamSpec, _TypeVar]),
        ]):
    """
    posthooks are called one argument.
    posthook(c: _OpenedCamera): ...
    """
    def inner(func):
        def inner2a(camera_no: typing.Optional[int],
                    connection: typing.Union[CONNECTION, DEVICE_PARAM],
                    save_xml: int, open_mode: int) -> _OpenedCamera:
            if isinstance(connection, CONNECTION):
                con = CONNECTION.from_buffer_copy(connection)
            elif isinstance(connection, DEVICE_PARAM):
                con = connection.toConnection()
            else:
                raise TypeError(
                    f"connection must be CONNECTION or DEVICE_PARAM, "
                    f"not {connection.__class__.__name__}"
                )

            def _open(camera_no: int) -> _OpenedCamera:
                func(camera_no, con, save_xml, open_mode)
                return _OpenedCamera(camera_no, con)

            if camera_no is not None:
                return _open(camera_no)
            for i in range(1, 50):
                if _OpenedCamera._instance_table.get(i):
                    continue
                try:
                    return _open(i)
                except GEVError as e:
                    if e.error_code != GEVError.GEV_STATUS_ALREADY_OPEN:
                        raise
            # cannot open
            GEVError.raise_iferror(GEVError.GEV_STATUS_ALREADY_OPEN)
        def inner2b(camera: _OpenedCamera) -> None:
            for hook in posthooks:
                hook(camera)
        def inner2(*args, **kwargs) -> _OpenedCamera:
            camera=inner2a(*args, **kwargs)
            try:
                inner2b(camera)
                return camera
            except:
                camera.close()
                raise
        return _funcwrap_reprstr(inner2, func)
    return inner

def _funcwrap_reprstr(wrapper, wrapped):
    """
    functools.update_wrapper is not update "__repr__" and "__str__".
    this function update there attributes.
    """
    class core:
        def __init__(self, wrapper_func, wrapped_func):
            self.wrapper_func=wrapper_func
            self.wrapped_func=wrapped_func
        def __call__(self, *args, **kwargs):
            return self.wrapper_func(*args, **kwargs)
        def __repr__(self):
            return repr(self.wrapped_func)
        def __str__(self):
            return str(self.wrapped_func)
    c=core(wrapper, wrapped)
    return functools.update_wrapper(c, wrapped)

# ** General functions **
@_decoinit(_OpenedCamera.initXml)
@callwrapper(c_uint8, InRef(CONNECTION), InConstant(c_void_p, None), c_uint8, c_uint8)
def init(camera_no: typing.Optional[int],
         connection: typing.Union[CONNECTION, DEVICE_PARAM],
         save_xml: bool = False,
         open_mode: typing.Union[Access, int] = Access.exclusive,
         ) -> _OpenedCamera:
    return ... # type:ignore

@callwrapper(Out(DISCOVERY), InConstant(c_void_p, None), c_uint32, c_bool, c_uint16)
def discovery(timeout_ms: int, ignore_subnet: bool=False, port: int=0) -> DISCOVERY:
    return ... # type:ignore

@callwrapper(Out(ENUMERATE_ADAPTER))
def enumerateAdapters() -> ENUMERATE_ADAPTER:
    return ... # type:ignore

@callwrapper(Out(DISCOVERY),
             InRef(ADAPTER_PARAM),
             InConstant(c_void_p, None),
             c_uint32,
             c_bool,
             c_uint16,
)
def discoveryAdapter(adapter: ADAPTER_PARAM,
                     d_timeout: int,
                     ignore_subnet: bool,
                     port: int) -> DISCOVERY:
    return ... # type:ignore

@callwrapper(ipv4_t, ipv4_t, ipv4_t, InRef(macaddr_t), ipv4_t)
def forceIp(new_ip: str, subnet: str, gateway: str,
            mac: str, adapter_ip: str) -> None:
    return ... # type:ignore

@callwrapper(ipv4_t, ipv4_t, ipv4_t, Out(c_uint8), c_uint32, c_uint16)
def __GEVCheckDeviceStatus(ip_adapter, mask_adapter, ip_device, ack_timeout, port):
    return ... # type:ignore
def checkDeviceStatus(ip_adapter: str,
                      mask_adapter: str,
                      ip_device: str,
                      ack_timeout: int,
                      port: int = 0) -> DiscoveryStatus:
    return DiscoveryStatus(__GEVCheckDeviceStatus(
        ip_adapter, mask_adapter, ip_device, ack_timeout, port))
    return ... # type:ignore

# issueAction family
@callwrapper(
    InRef(c_uint8*0),
    InExpression(c_size_t, lambda a,*_:len(a)),
    InRef(ACTION_KEYS),
    c_uint64,
    c_uint32,
    _ctypes.CFuncPtr,
    InConstant(c_void_p, None),
)
def __GEVIssueActionCommandBroadcast(
        cameras, keys, actiontime, timeoutms, callback):
    return ... # type:ignore

@callwrapper(
    InRef(c_uint8*0),
    InExpression(c_size_t, lambda a,*_:len(a)),
    InRef(ACTION_KEYS),
    c_uint64,
    c_uint32,
    _ctypes.CFuncPtr,
    InConstant(c_void_p, None),
)
def __GEVIssueActionCommandBroadcastDirected(
        cameras, keys, actiontime, timeoutms, callback):
    return ... # type:ignore

@callwrapper(
    InRef(ipv4_t*0),
    InExpression(c_size_t, lambda a,*_:len(a)),
    InRef(ACTION_KEYS),
    c_uint64,
    c_uint32,
    _ctypes.CFuncPtr,
    InConstant(c_void_p, None),
)
def __GEVIssueActionCommandAdapter(
        adaptersip, keys, actiontime, timeoutms, callback):
    return ... # type:ignore

@callwrapper(
    InRef(ipv4_t*0),
    InExpression(c_size_t, lambda a,*_:len(a)),
    InRef(ACTION_KEYS),
    c_uint64,
    c_uint32,
    _ctypes.CFuncPtr,
    InConstant(c_void_p, None),
)
def __GEVIssueActionCommandAdapterDirected(
        adaptersip, keys, actiontime, timeoutms, callback):
    return ... # type:ignore

def _issueAction(corefunc, targets, keys, actiontime, timeoutms, callback):
    inner_exception = None
    if callback is not None:
        @ctypes.CFUNCTYPE(c_uint8, c_uint8, ipv4_t, c_uint16, c_void_p)
        def callbackwrap(camno, ipv4, ecode, _):
            try:
                camera = _OpenedCamera._getfrom_camera_no(camno)
                ip = str(ipv4)
                error = GEVError(ecode) if ecode != 0 else None
                callbackresult = callback(camera, str(ip), error)
                return callbackresult if callbackresult is not None else 0
            except BaseException as e:
                nonlocal inner_exception
                inner_exception = e
                return 1
    else:
        callbackwrap = None
    try:
        corefunc(targets, keys, actiontime, timeoutms, callbackwrap)
    finally:
        del callbackwrap
        if inner_exception is not None:
            raise inner_exception


def issueActionCommandBroadcast(
        cameras: typing.Iterable[_OpenedCamera],
        keys: ACTION_KEYS,
        actiontime,
        timeoutms:int,
        callback:typing.Callable[
            [typing.Optional[_OpenedCamera], str, typing.Optional[GEVError]],
            int]):
    """
    the callback parameter need to define like berow.
    def callback(camera:None, ip:str, error:GEVError|None) -> int|None:
    return value:
        0: continue to wait acknowledge.
        1: decontinue to waiting, and instantly return.
    """
    camnos=tuple(map(lambda c:c.camera_no, cameras))
    return _issueAction(
        __GEVIssueActionCommandBroadcast,
        camnos, keys, actiontime, timeoutms, callback)

def issueActionCommandBroadcastDirected(
        cameras: typing.Iterable[_OpenedCamera],
        keys: ACTION_KEYS,
        actiontime,
        timeoutms:int,
        callback:typing.Callable[
            [typing.Optional[_OpenedCamera], str, typing.Optional[GEVError]],
            int]):
    """
    the callback parameter need to define like berow.
    def callback(camera:None, ip:str, error:GEVError|None) -> int|None:
    return value:
        0: continue to wait acknowledge.
        1: decontinue to waiting, and instantly return.
    """
    camnos=tuple(map(lambda c:c.camera_no, cameras))
    return _issueAction(
        __GEVIssueActionCommandBroadcastDirected,
        camnos, keys, actiontime, timeoutms, callback)

def issueActionCommandAdapter(
        adaptersip: typing.Iterable[ipv4_t],
        keys: ACTION_KEYS,
        actiontime:int,
        timeoutms:int,
        callback:typing.Callable[
            [typing.Optional[_OpenedCamera], str, typing.Optional[GEVError]],
            int]):
    """
    the callback parameter need to define like berow.
    def callback(camera:None, ip:str, error:GEVError|None) -> int|None:
    return value:
        0: continue to wait acknowledge.
        1: decontinue to waiting, and instantly return.
    """
    adaptersip=tuple(map(ipv4_t, adaptersip))
    return _issueAction(
        __GEVIssueActionCommandAdapter,
        adaptersip, keys, actiontime, timeoutms, callback)

def issueActionCommandAdapterDirected(
        adaptersip: typing.Iterable[ipv4_t],
        keys: ACTION_KEYS,
        actiontime:int,
        timeoutms:int,
        callback:typing.Callable[
            [typing.Optional[_OpenedCamera], str, typing.Optional[GEVError]],
            int]):
    """
    the callback parameter need to define like berow.
    def callback(camera:None, ip:str, error:GEVError|None) -> int|None:
    return value:
        0: continue to wait acknowledge.
        1: decontinue to waiting, and instantly return.
    """
    adaptersip=tuple(map(ipv4_t, adaptersip))
    return _issueAction(
        __GEVIssueActionCommandAdapterDirected,
        adaptersip, keys, actiontime, timeoutms, callback)


# DLL version.
def getDllVersion() -> typing.Tuple[int, int, int]: # major, minor, micro
    return _loadcore.GEVGetDllVersion()
def getDllAbiVersion() -> typing.Tuple[int, int, int]: # major, minor, micro
    return _loadcore.GEVGetDllAbiVersion()
