# (c) 2023 Kowa Optronics Co.,Ltd.
# License: MIT, see https://opensource.org/license/mit/

import sys
import ctypes
from ctypes import ( # pylint: disable = unused-import
    c_int, c_uint,
    c_int8, c_uint8,
    c_int16, c_uint16,
    c_int32, c_uint32,
    c_int64, c_uint64,
    c_char,
    c_float,
    c_double,
    c_bool,
    c_void_p,
)

from . import enum as _enum
import typing

class ipv4_t(ctypes.BigEndianStructure):
    _fields_ = [
        ("value", c_uint32),
    ]
    def __init__(self, value: typing.Optional[typing.Union[int, str]] = 0):
        if isinstance(value, str):
            self.value = self._convert_to_ctypes(value)
        else:
            super().__init__(value)
    @staticmethod
    def _convert_to_ctypes(value: str) -> int:
        """
        convert from str ipv4addr to bigendian uint32.
        follow to short ipaddr
        e.g. "192.168.1.2" -> 0xc0a80102 (big endian)
        e.g. "192.168.258" -> 0xc0a80102 (big endian)
        """
        if isinstance(value, int):
            return value
        tv = tuple(map(int, value.split(".")))
        bv = bytes(tv) if len(tv) == 4 else (
            bytes(tv[:-1]) + bytes(tv[-1].to_bytes(5-len(tv), "big"))
        )
        return int.from_bytes(bv, "big")
    @staticmethod
    def _convert_from_ctypes(value: int) -> str:
        """
        convert from bigendian uint32 to str.
        e.g. 0xc0a80102 -> "192.168.1.2"
        """
        if isinstance(value, str):
            return value
        return ".".join(map(str, int(value).to_bytes(4, "big")))
    @staticmethod
    def convert_to_ctypes(value: str):
        return __class__(__class__._convert_to_ctypes(value))
    def convert_from_ctypes(self) -> str:
        return __class__._convert_from_ctypes(self.value)
    def __repr__(self):
        return f"<{self.__class__.__name__} {self}>"
    def __str__(self):
        return self.convert_from_ctypes()

class _ipv4_hostbyteorder_t(ctypes.Structure):
    """ To some API, they wrong byteorder of inetaddr. """
    _fields_ = [
        ("value", c_uint32),
    ]
    def __init__(self, value: typing.Optional[typing.Union[int, str]] = 0):
        if isinstance(value, str):
            self.value = self._convert_to_ctypes(value)
        else:
            super().__init__(value)
    @staticmethod
    def _convert_to_ctypes(value: str) -> int:
        """
        convert from str ipv4addr to bigendian uint32.
        follow to short ipaddr
        e.g. "192.168.1.2" -> 0xc0a80102 (big endian)
        e.g. "192.168.258" -> 0xc0a80102 (big endian)
        """
        if isinstance(value, int):
            return value
        tv = tuple(map(int, value.split(".")))
        bv = bytes(tv) if len(tv) == 4 else (
            bytes(tv[:-1]) + bytes(tv[-1].to_bytes(5-len(tv), "big"))
        )
        return int.from_bytes(bv, "big")
    @staticmethod
    def _convert_from_ctypes(value: int) -> str:
        """
        convert from bigendian uint32 to str.
        e.g. 0xc0a80102 -> "192.168.1.2"
        """
        if isinstance(value, str):
            return value
        return ".".join(map(str, int(value).to_bytes(4, "big")))
    @staticmethod
    def convert_to_ctypes(value: str):
        return __class__(__class__._convert_to_ctypes(value))
    def convert_from_ctypes(self) -> str:
        return __class__._convert_from_ctypes(self.value)
    def __repr__(self):
        return f"<{self.__class__.__name__} {self}>"
    def __str__(self):
        return self.convert_from_ctypes()


class macaddr_t(ctypes.Structure):
    _fields_ = [
        ("value", c_uint8*6),
    ]
    __targettype = c_uint8*6
    @staticmethod
    def _convert_to_ctypes(value: typing.Union[str, typing.Iterable[int]]) -> c_uint8*6:
        """
        convert from str macaddr to ctypes_array.
        e.g. "01:02:03:04:05:06" -> [1,2,3,4,5,6]
        e.g. b"\x01\x02\x03\x04\x05\x06" -> [1,2,3,4,5,6]
        e.g. (1,2,3,4,5,6) -> [1,2,3,4,5,6]
        """
        if isinstance(value, str):
            l = tuple(map(lambda x:int(x, 16), value.split(":")))
        else:
            l = tuple(l)
        if len(l) != 6:
            raise ValueError(f"Invalid macaddr: {value}")
        return (c_uint8*6)(*l)
    @staticmethod
    def _convert_from_ctypes(value: c_uint8*6) -> str:
        """
        convert from ctypes_array to str macaddr.
        e.g. [1,2,3,4,5,6] -> "01:02:03:04:05:06"
        """
        return ":".join(map("{:02x}".format, value))
    @staticmethod
    def convert_to_ctypes(value: str):
        return __class__(__class__._convert_to_ctypes(value))
    def convert_from_ctypes(self) -> str:
        return __class__._convert_from_ctypes(self.value)
    def __repr__(self):
        return f"<{self.__class__.__name__} {self}>"
    def __str__(self):
        return self.convert_from_ctypes()

def _getsetproperty(target: type, baseattr: str, usertype:type=None):
    def _getter(self):
        return target.convert_from_ctypes(getattr(self, baseattr))
    def _setter(self, value):
        setattr(self, baseattr, target.convert_to_ctypes(value))
    if not issubclass(target, ctypes.Structure) and usertype is not None:
        # primitive type
        def _getter(self):
            return usertype(getattr(self, baseattr))
        def _setter(self, value):
            setattr(self, baseattr, target(value))
    return property(_getter, _setter)

def _strrawproperty(length:int, baseattr: str):
    def _getter(self):
        bin = getattr(self, baseattr)
        try:
            return bin.decode("UTF8", "strict")
        except UnicodeDecodeError:
            return bin
    def _setter(self, value:str):
        setattr(self, baseattr, value.encode("UTF8")[:length])
    return property(_getter, _setter)



class AutoReprStructure(ctypes.Structure):
    def __init__(self, **kwargs):
        if kwargs:
            fieldnames=dir(self)
        for k,v in kwargs.items():
            if k not in fieldnames:
                raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{k}'")
            setattr(self, k, v)
    def __reprstr(self, isrepr: bool) -> str:
        def _inner(name_value):
            name,value=name_value
            return f"{name}={value}"
        single = lambda fieldname: self.__reprstr_single(fieldname, isrepr)
        res = tuple(single(fname) for fname,ftype in self._fields_)
        reprtagopen  = "<" if isrepr and None in res else ""
        reprtagclose = ">" if isrepr and None in res else ""
        return (
            f"{reprtagopen}{self.__class__.__name__}("
            f"{', '.join(map(_inner, filter(bool, res)))}"
            f"){reprtagclose}"
        )
    def __reprstr_single(self, fieldname: str, isrepr: bool):
        """return: (fieldname, result) or None"""
        # replace "_field" -> "field"
        if fieldname.startswith("_"):
            publicname = fieldname.lstrip("_")
            if hasattr(self.__class__, publicname):
                fieldname = publicname
            else:
                return None
        value = getattr(self, fieldname)
        if not isrepr:
            s = self._special_str(fieldname, value)
            if isinstance(s, str):
                return fieldname, s
        # use repr, if not defined str.
        s = self._special_repr(fieldname, value)
        if isinstance(s, str):
            return fieldname, s
        reprstr = repr if isrepr else str
        return fieldname, reprstr(value)
    # common __repr__ and __str__.
    def __repr__(self):
        return self.__reprstr(True)
    def __str__(self):
        return self.__reprstr(False)
    # they functions called __repr__ and __str__.
    # implemente them functions in drived classes.
    # customize some fields repr or str.
    def _special_repr(self, fieldname: str, value) -> typing.Optional[str]: # pylint: disable = unused-argument
        pass # NotImplementde
    def _special_str(self, fieldname: str, value) -> typing.Optional[str]: # pylint: disable = unused-argument
        pass # NotImplementde

# C defined parameter
MAX_ADAPTER_NAME_LEN=256
CAMERA_COUNT_DISCOVERY=128

# C Structures
class _FeatureListElement(AutoReprStructure):
    _fields_ = [
        ("_Next"           , ctypes.c_void_p), # pointer to this class
        ("Index"           , c_uint32),
        ("_Name"           , ctypes.c_char_p),
        ("_Type"           , c_uint8),
        ("Level"           , c_uint8),
    ]

    Index: int
    @property
    def Name(self) -> str:
        bin = self._Name
        try:
            return bin.decode("UTF8", "strict")
        except UnicodeDecodeError:
            return bin
    Type: _enum.Type = _getsetproperty(c_uint8, "_Type", _enum.Type)
    Level: int

class FeatureList:
    _pelement_t = ctypes.POINTER(_FeatureListElement)
    def __init__(self, first_ptr):
        self._first_ptr = first_ptr
        self._cache = None
    def __iter__(self) -> typing.Iterator[_FeatureListElement]:
        pelement_t = self._pelement_t
        pcurrent = ctypes.cast(self._first_ptr, self._pelement_t)
        while pcurrent:
            contents = pcurrent.contents
            yield contents
            pcurrent = ctypes.cast(contents._Next, self._pelement_t)
    def _getcache(self):
        if self._cache is None:
            self._cache = tuple(x for x in self)
        return self._cache
    def __getitem__(self, *args):
        return self._getcache().__getitem__(*args)
    def __len__(self):
        return len(self._getcache())

class FEATURE_PARAMETER(AutoReprStructure):
    _fields_ = [
        ("_Type"           , c_uint8),
        ("Min"             , c_int64),
        ("Max"             , c_int64),
        ("OnValue"         , c_uint32),
        ("OffValue"        , c_uint32),
        ("_AccessMode"     , c_uint16),
        ("_Representation" , c_uint16),
        ("Inc"             , c_uint32),
        ("CommandValue"    , c_uint32),
        ("Length"          , c_uint32),
        ("EnumerationCount", c_uint8),
        ("_Visibility"     , c_uint8),
        ("FloatMin"        , c_double),
        ("FloatMax"        , c_double),
        ("FloatInc"        , c_double),
        ("_IsImplemented"  , c_uint8),
        ("_IsAvailable"    , c_uint8),
        ("_IsLocked"       , c_uint8),
        ("_Sign"           , c_uint8),
        ("Address"         , c_uint32),
        ("_DisplayNotation", c_uint8),
        ("DisplayPrecision", c_uint8),
        ("InvalidatorCount", c_uint8),
        ("PollingTime"     , c_int64),
    ]

    Type: _enum.Type = _getsetproperty(c_uint8, "_Type", _enum.Type)
    Min: int
    Max: int
    OnValue: int
    OffValue: int
    AccessMode: _enum.AccessMode = _getsetproperty(c_uint16, "_AccessMode", _enum.AccessMode)
    Representation: _enum.Representation = _getsetproperty(c_uint16, "_Representation", _enum.Representation)
    Inc: int
    CommandValue: int
    Length: int
    EnumerationCount: int
    Visibility: _enum.Visibility = _getsetproperty(c_uint8, "_Visibility", _enum.Visibility)
    FloatMin: float
    FloatMax: float
    FloatInc: float
    IsImplemented: bool = _getsetproperty(c_uint8, "_IsImplemented", bool)
    IsAvailable: bool = _getsetproperty(c_uint8, "_IsAvailable", bool)
    IsLocked: bool = _getsetproperty(c_uint8, "_IsLocked", bool)
    Sign: _enum.Sign = _getsetproperty(c_uint8, "_Sign", _enum.Sign)
    Address: int
    DisplayNotation: _enum.DisplayNotation = _getsetproperty(c_uint8, "_DisplayNotation", _enum.DisplayNotation)
    DisplayPrecision: int
    InvalidatorCount: int
    PollingTime: int

class DEVICE_PARAM(AutoReprStructure):
    """
    discovered camera info and network parameter.
    """
    # note:
    #      c_char*N fields are defined BYTE[N] in C lang header.
    #      but they are only treated char*. e.g. strcpy((char*)pdevice->manuf, buffer);
    #      so therefore, this wrapper no meaning treat c_uint8 them.
    _fields_ = [
        ("_IP"             , ipv4_t),
        ("_manuf"          , c_char*32),
        ("_model"          , c_char*32),
        ("_version"        , c_char*32),
        ("_AdapterIP"      , ipv4_t),
        ("_AdapterMask"    , ipv4_t),
        ("_Mac"            , macaddr_t),
        ("_subnet"         , ipv4_t),
        ("_gateway"        , ipv4_t),
        ("_adapter_name"   , c_char*(MAX_ADAPTER_NAME_LEN + 4)),
        ("_serial"         , c_char*16),
        ("_userdef_name"   , c_char*16),
        ("_status"         , c_uint8),
    ]
    IP: str = _getsetproperty(ipv4_t, "_IP")
    AdapterIP: str = _getsetproperty(ipv4_t, "_AdapterIP")
    AdapterMask: str = _getsetproperty(ipv4_t, "_AdapterMask")
    subnet: str = _getsetproperty(ipv4_t, "_subnet")
    gateway: str = _getsetproperty(ipv4_t, "_gateway")
    Mac: str = _getsetproperty(macaddr_t, "_Mac")
    manuf: str = _strrawproperty(32, "_manuf")
    model: str = _strrawproperty(32, "_model")
    version: str = _strrawproperty(32, "_version")
    adapter_name: str = _strrawproperty(MAX_ADAPTER_NAME_LEN + 4, "_adapter_name")
    serial: str = _strrawproperty(16, "_serial")
    userdef_name: str = _strrawproperty(16, "_userdef_name")
    status: _enum.DiscoveryStatus = _getsetproperty(c_uint8, "_status", _enum.DiscoveryStatus)

    def toConnection(self, **kwargs) -> "CONNECTION":
        """
        to connention parameter from this.
        can override use kwargs parameter.
        e.g. self.toConnection(adapter_name=b"eth1")
        """
        d={
            "AdapterIP":self.AdapterIP,
            "AdapterMask":self.AdapterMask,
            "adapter_name":self.adapter_name,
            "IP_CANCam":self.IP,
            "PortCtrl":0,
            "PortData":0,
            "PortMessage":0,
        }
        d.update(kwargs)
        return CONNECTION(**d)

class ADAPTER_PARAM(AutoReprStructure):
    _fields_ = [
        ("_AdapterIP"      , ipv4_t),
        ("_AdapterMask"    , ipv4_t),
        ("_AdapterName"    , c_char*(MAX_ADAPTER_NAME_LEN + 4)),
    ]
    AdapterIP: str = _getsetproperty(ipv4_t, "_AdapterIP")
    AdapterMask: str = _getsetproperty(ipv4_t, "_AdapterMask")
    AdapterName: str = _strrawproperty(MAX_ADAPTER_NAME_LEN + 4, "_AdapterName")

class ENUMERATE_ADAPTER(AutoReprStructure):
    _fields_ = [
        ("Count"           , c_uint8),
        ("Param"           , ADAPTER_PARAM*CAMERA_COUNT_DISCOVERY),
    ]
    Count: int
    Param: ADAPTER_PARAM*CAMERA_COUNT_DISCOVERY

    def __bool__(self):
        return self.Count != 0
    def __len__(self):
        return self.Count
    def __iter__(self) -> typing.Iterator[ADAPTER_PARAM]:
        return iter(self.Param[:self.Count])
    def __getitem__(self, index:typing.Union[int, slice]) -> ADAPTER_PARAM:
        return self.Param[:self.Count][index]
    def _special_repr(self, fieldname, value):
        if fieldname == "Param":
            return f"[{', '.join(map(repr, self))}]"
        return None

class DISCOVERY(AutoReprStructure):
    """ discovered cameras. """
    _fields_ = [
        ("Count"           , c_uint8),
        ("Param"           , DEVICE_PARAM*CAMERA_COUNT_DISCOVERY),
    ]
    Count: int
    Param: DEVICE_PARAM*CAMERA_COUNT_DISCOVERY
    # this class is treated array-like.
    # e.g. d0=discovery[0]
    # e.g. for d in discovery:
    #          ... # d is DEVICE_PARAM instance, up to discovery.Count
    def __bool__(self):
        return self.Count != 0
    def __len__(self):
        return self.Count
    def __iter__(self) -> typing.Iterator[DEVICE_PARAM]:
        return iter(self.Param[:self.Count])
    def __getitem__(self, index:typing.Union[int, slice]) -> DEVICE_PARAM:
        return self.Param[:self.Count][index]
    def _special_repr(self, fieldname, value):
        if fieldname == "Param":
            return f"[{', '.join(map(repr, self))}]"
        return None

class CONNECTION(AutoReprStructure):
    """
    network parameter at connect device
    """
    _fields_ = [
        ("_IP_CANCam"      , ipv4_t),
        ("PortData"        , c_uint16),
        ("PortCtrl"        , c_uint16),
        ("_AdapterIP"      , ipv4_t),
        ("_AdapterMask"    , ipv4_t),
        ("_adapter_name"   , c_char*(MAX_ADAPTER_NAME_LEN + 4)),
        ("PortMessage"     , c_uint16),
    ]
    IP_CANCam: str = _getsetproperty(ipv4_t, "_IP_CANCam")
    AdapterIP: str = _getsetproperty(ipv4_t, "_AdapterIP")
    AdapterMask: str = _getsetproperty(ipv4_t, "_AdapterMask")
    adapter_name: str = _strrawproperty(MAX_ADAPTER_NAME_LEN + 4, "_adapter_name")

class CLINK_STATUS(AutoReprStructure):
    _fields_ = [
        ("receive_count"         , c_uint8),
        ("transmit_count"        , c_uint8),
        ("transmit_buffer_full"  , c_uint8),
        ("transmit_buffer_empty" , c_uint8),
        ("reveice_buffer_full"   , c_uint8),
        ("reveice_data_available", c_uint8),
    ]
    receive_count: int
    transmit_count: int
    transmit_buffer_full: int
    transmit_buffer_empty: int
    reveice_buffer_full: int
    reveice_data_available: int

class CHANNEL_PARAMETER(AutoReprStructure):
    _fields_ = [
        ("heartbeat_timeout", c_uint32),
        ("timeout"         , c_uint32),
        ("retry"           , c_uint8),
        ("sc_timeout"       , c_uint32),
        ("sc_packet_resend" , c_uint8),
        ("sc_image_wait_timeout", c_uint32),
    ]
    heartbeat_timeout: int
    timeout: int
    retry: int
    sc_timeout: int
    sc_packet_resend: int
    sc_image_wait_timeout: int

class IMAGE_HEADER(AutoReprStructure):
    _fields_ = [
        ("FrameCounter"    , c_int64),
        ("TimeStamp"       , c_int64),
        ("PixelType"       , c_uint32),
        ("SizeX"           , c_uint32),
        ("SizeY"           , c_uint32),
        ("OffsetX"         , c_uint32),
        ("OffsetY"         , c_uint32),
        ("PaddingX"        , c_uint16),
        ("PaddingY"        , c_uint16),
        ("MissingPacket"   , c_int32),
        ("PayloadType"     , c_uint16),
        ("ChunkDataPayloadLength", c_uint32),
        ("ChunkLayoutId"   , c_uint32),
    ]
    FrameCounter: int
    TimeStamp: int
    PixelType: int
    SizeX: int
    SizeY: int
    OffsetX: int
    OffsetY: int
    PaddingX: int
    PaddingY: int
    MissingPacket: int
    PayloadType: int
    ChunkDataPayloadLength: int
    ChunkLayoutId: int

class ACTION_KEYS(AutoReprStructure):
    _fields_ = [
        ("DeviceKey", c_uint32),
        ("GroupKey", c_uint32),
        ("GroupMask", c_uint32),
    ]
    DeviceKey: int
    GroupKey: int
    GroupMask: int
