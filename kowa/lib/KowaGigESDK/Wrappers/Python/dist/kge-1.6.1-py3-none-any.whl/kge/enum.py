from enum import IntEnum

class _Enum(IntEnum):
    def __str__(self):
        return self.name

class Type(_Enum):
    category = 0
    feature = 1
    integer = 2
    float = 3
    string = 4
    enumeration = 5
    command = 6
    boolean = 7
    register = 8
    port = 9

class AccessMode(_Enum):
    ro = 0x524f
    rw = 0x5257
    wo = 0x574f

class Visibility(_Enum):
    invisible = 0
    beginner = 1
    expert = 2
    guru = 3

class Sign(_Enum):
    unsigned = 0
    signed = 1

class Representation(_Enum):
    linear = 0
    logarithmic = 1
    boolean = 2
    pure_number = 3
    hex_number = 4
    undefinded = 5
    ipv4address = 6
    macaddress = 7

class DisplayNotation(_Enum):
    automatic = 0
    fixed = 1
    scientific = 2

class DiscoveryStatus(_Enum):
    ok = 0
    already_open = 1
    not_same_subnet = 2
    control_open = 3
    communication_error = 4
    not_checked = 5

class Access(_Enum):
    open = 0
    exclusive = 1
    control = 2
